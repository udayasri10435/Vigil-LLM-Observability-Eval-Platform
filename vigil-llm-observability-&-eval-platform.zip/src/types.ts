export type SpanType = 'chain' | 'llm' | 'retriever' | 'tool' | 'guardrail';
export type SpanStatus = 'success' | 'error' | 'warning';

export interface Span {
  id: string;
  name: string;
  type: SpanType;
  startTime: number; // offset ms from trace start
  durationMs: number;
  status: SpanStatus;
  model?: string;
  input: any;
  output: any;
  tokens?: {
    prompt: number;
    completion: number;
    total: number;
  };
  cost?: number;
  metadata?: Record<string, any>;
  children?: Span[];
}

export interface Trace {
  id: string;
  sessionTitle: string;
  environment: 'production' | 'staging' | 'canary';
  projectName: string;
  timestamp: string;
  totalDurationMs: number;
  totalCostUSD: number;
  totalTokens: number;
  status: SpanStatus;
  faithfulnessScore?: number; // 0-100
  hallucinationRisk?: 'LOW' | 'MEDIUM' | 'CRITICAL';
  model: string;
  tags: string[];
  userId: string;
  rootSpan: Span;
}

export interface PromptVersion {
  id: string;
  promptSlug: string;
  name: string;
  version: string;
  tag: 'production' | 'staging' | 'canary' | 'deprecated';
  systemInstruction: string;
  template: string;
  model: string;
  temperature: number;
  topP: number;
  commitMessage: string;
  author: string;
  createdAt: string;
  metrics: {
    totalRuns: number;
    avgLatencyMs: number;
    avgCostUSD: number;
    faithfulnessRate: number; // e.g. 98.4%
  };
  variables: string[];
}

export interface ClaimAssessment {
  claim: string;
  status: 'grounded' | 'hallucinated' | 'unverifiable';
  reason: string;
  excerptInContext?: string;
}

export interface HallucinationEvalResult {
  faithfulnessScore: number;
  hallucinationRisk: 'LOW' | 'MEDIUM' | 'CRITICAL';
  verdict: 'PASSED' | 'WARNING' | 'FAILED';
  summary: string;
  claims: ClaimAssessment[];
  groundedCorrection: string;
  evalLatencyMs?: number;
  judgeModel?: string;
  evaluatedAt: string;
}

export interface ABComparisonResult {
  variantA: {
    name: string;
    model: string;
    output: string;
    latencyMs: number;
    inputTokens: number;
    outputTokens: number;
    cost: number;
    score: number;
  };
  variantB: {
    name: string;
    model: string;
    output: string;
    latencyMs: number;
    inputTokens: number;
    outputTokens: number;
    cost: number;
    score: number;
  };
  judge: {
    winner: 'VARIANT_A' | 'VARIANT_B' | 'TIE';
    scoreA: number;
    scoreB: number;
    criteriaScores: {
      relevanceA: number;
      relevanceB: number;
      accuracyA: number;
      accuracyB: number;
      clarityA: number;
      clarityB: number;
    };
    verdictSummary: string;
  };
  delta: {
    latencyMs: number;
    costSavingsPercent: number;
    scoreDiff: number;
  };
  timestamp: string;
}
