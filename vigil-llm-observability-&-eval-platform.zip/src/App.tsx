import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { TracesView } from './components/TracesView';
import { PromptsView } from './components/PromptsView';
import { ABTestingView } from './components/ABTestingView';
import { HallucinationView } from './components/HallucinationView';
import { CostView } from './components/CostView';
import { PlaygroundView } from './components/PlaygroundView';
import { SDKView } from './components/SDKView';
import { INITIAL_TRACES, INITIAL_PROMPTS } from './data/mockData';
import { Trace, PromptVersion } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('traces');
  const [selectedProject, setSelectedProject] = useState<string>('Customer-Support-RAG');
  const [environment, setEnvironment] = useState<string>('production');
  const [apiConnected, setApiConnected] = useState<boolean>(true);

  const [traces, setTraces] = useState<Trace[]>(INITIAL_TRACES);
  const [prompts, setPrompts] = useState<PromptVersion[]>(INITIAL_PROMPTS);

  // Cross-tab transfer states
  const [playgroundInitPrompt, setPlaygroundInitPrompt] = useState<string | undefined>();
  const [playgroundInitSystem, setPlaygroundInitSystem] = useState<string | undefined>();

  const [hallucinationInitContext, setHallucinationInitContext] = useState<string | undefined>();
  const [hallucinationInitPrompt, setHallucinationInitPrompt] = useState<string | undefined>();
  const [hallucinationInitOutput, setHallucinationInitOutput] = useState<string | undefined>();

  // Check backend server status
  useEffect(() => {
    fetch('/api/status')
      .then((res) => res.json())
      .then((data) => {
        setApiConnected(data.status === 'operational');
      })
      .catch(() => {
        setApiConnected(false);
      });
  }, []);

  const handleOpenPlaygroundWithTrace = (trace: Trace) => {
    const rootInput = trace.rootSpan.input;
    const promptText = typeof rootInput === 'string' ? rootInput : JSON.stringify(rootInput, null, 2);
    setPlaygroundInitPrompt(promptText);
    setActiveTab('playground');
  };

  const handleRunHallucinationScan = (context: string, prompt: string, output: string) => {
    setHallucinationInitContext(context);
    setHallucinationInitPrompt(prompt);
    setHallucinationInitOutput(output);
    setActiveTab('hallucination');
  };

  const handlePromotePrompt = (id: string, tag: PromptVersion['tag']) => {
    setPrompts((prev) =>
      prev.map((p) => {
        if (p.id === id) {
          return { ...p, tag };
        }
        // If promoting to production, downgrade old production for same slug
        if (tag === 'production' && p.promptSlug === prev.find((x) => x.id === id)?.promptSlug && p.tag === 'production') {
          return { ...p, tag: 'deprecated' };
        }
        return p;
      })
    );
  };

  const handleSaveNewVersion = (newVer: PromptVersion) => {
    setPrompts((prev) => [newVer, ...prev]);
  };

  const handleTestPrompt = (prompt: PromptVersion) => {
    setPlaygroundInitPrompt(prompt.template);
    setPlaygroundInitSystem(prompt.systemInstruction);
    setActiveTab('playground');
  };

  const handleTraceCreated = (newTrace: Trace) => {
    setTraces((prev) => [newTrace, ...prev]);
  };

  return (
    <div className="min-h-screen bg-[#090d16] text-zinc-100 flex flex-col font-sans selection:bg-indigo-500/30 selection:text-indigo-200">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        selectedProject={selectedProject}
        setSelectedProject={setSelectedProject}
        environment={environment}
        setEnvironment={setEnvironment}
        apiConnected={apiConnected}
      />

      {/* Main Content Area */}
      <main className="flex-1 pb-16">
        {activeTab === 'traces' && (
          <TracesView
            traces={traces}
            onOpenPlaygroundWithTrace={handleOpenPlaygroundWithTrace}
            onRunHallucinationScan={handleRunHallucinationScan}
          />
        )}

        {activeTab === 'prompts' && (
          <PromptsView
            prompts={prompts}
            onPromotePrompt={handlePromotePrompt}
            onSaveNewVersion={handleSaveNewVersion}
            onTestPrompt={handleTestPrompt}
          />
        )}

        {activeTab === 'ab-testing' && <ABTestingView prompts={prompts} />}

        {activeTab === 'hallucination' && (
          <HallucinationView
            initialContext={hallucinationInitContext}
            initialPrompt={hallucinationInitPrompt}
            initialOutput={hallucinationInitOutput}
          />
        )}

        {activeTab === 'cost' && <CostView />}

        {activeTab === 'playground' && (
          <PlaygroundView
            onTraceCreated={handleTraceCreated}
            onAuditHallucination={handleRunHallucinationScan}
            initialPromptText={playgroundInitPrompt}
            initialSystemText={playgroundInitSystem}
          />
        )}

        {activeTab === 'sdk' && <SDKView />}
      </main>

      {/* Footer bar */}
      <footer className="border-t border-zinc-900 bg-zinc-950 py-4 px-6 text-xs text-zinc-500 font-mono flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center space-x-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500" />
          <span>Vigil Observability Engine v2.4.0</span>
          <span>•</span>
          <span>Powered by Gemini 3.8 Flash & Flash-Lite</span>
        </div>
        <div className="flex items-center space-x-4">
          <button onClick={() => setActiveTab('sdk')} className="hover:text-zinc-300 transition">
            SDK Quickstart
          </button>
          <span>•</span>
          <button onClick={() => setActiveTab('traces')} className="hover:text-zinc-300 transition">
            Spans & Traces
          </button>
          <span>•</span>
          <button onClick={() => setActiveTab('cost')} className="hover:text-zinc-300 transition">
            Token Intelligence
          </button>
        </div>
      </footer>
    </div>
  );
}
