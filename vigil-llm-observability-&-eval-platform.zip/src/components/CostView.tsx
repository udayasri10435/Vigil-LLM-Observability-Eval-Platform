import React, { useState } from 'react';
import {
  Coins,
  TrendingDown,
  TrendingUp,
  Cpu,
  Zap,
  Layers,
  ArrowUpRight,
  ShieldAlert,
  Sparkles,
  Calculator,
  Sliders,
} from 'lucide-react';
import { COST_DATA } from '../data/mockData';

export const CostView: React.FC = () => {
  // Interactive Calculator State
  const [calcRequestsPerDay, setCalcRequestsPerDay] = useState(50000);
  const [calcPromptTokens, setCalcPromptTokens] = useState(1200);
  const [calcOutputTokens, setCalcOutputTokens] = useState(400);
  const [calcModel, setCalcModel] = useState<'gemini-3.8-flash' | 'gemini-3.1-flash-lite'>('gemini-3.8-flash');

  const flashRate = { input: 0.15, output: 0.60 };
  const liteRate = { input: 0.075, output: 0.30 };
  const activeRate = calcModel === 'gemini-3.1-flash-lite' ? liteRate : flashRate;

  const dailyPromptTokens = calcRequestsPerDay * calcPromptTokens;
  const dailyOutputTokens = calcRequestsPerDay * calcOutputTokens;
  const dailyCost = (dailyPromptTokens / 1e6) * activeRate.input + (dailyOutputTokens / 1e6) * activeRate.output;
  const monthlyCost = dailyCost * 30;

  // Comparison if switched to Flash-Lite
  const liteDailyCost = (dailyPromptTokens / 1e6) * liteRate.input + (dailyOutputTokens / 1e6) * liteRate.output;
  const liteMonthlyCost = liteDailyCost * 30;
  const potentialMonthlySavings = Math.max(0, monthlyCost - liteMonthlyCost);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white font-mono flex items-center space-x-2">
            <Coins className="w-5 h-5 text-amber-400" />
            <span>LLM Cost Tracking & Token Intelligence</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Real-time token burn rates, per-model expenditure, budget alerts, and automated cost-reduction recommendations.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs px-2.5 py-1 rounded bg-zinc-800 text-zinc-300 font-mono border border-zinc-700">
            BILLING CYCLE: SEP 1 - SEP 30
          </span>
        </div>
      </div>

      {/* High-level KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-400 font-mono">CURRENT MTD SPEND</span>
            <Coins className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-white font-mono">
              ${COST_DATA.currentSpendUSD.toFixed(2)}
            </span>
            <span className="text-xs text-zinc-400 font-mono">
              of ${COST_DATA.monthlyBudgetUSD} budget
            </span>
          </div>
          {/* Progress bar */}
          <div className="w-full bg-zinc-950 rounded-full h-1.5 mt-3 overflow-hidden">
            <div
              className="bg-amber-500 h-full rounded-full"
              style={{
                width: `${(COST_DATA.currentSpendUSD / COST_DATA.monthlyBudgetUSD) * 100}%`,
              }}
            />
          </div>
          <span className="text-[10px] text-zinc-500 font-mono block mt-2">
            33.7% of monthly budget consumed
          </span>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-400 font-mono">PROJECTED END-OF-MONTH</span>
            <TrendingUp className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-indigo-400 font-mono">
              ${COST_DATA.projectedSpendUSD.toFixed(2)}
            </span>
            <span className="text-xs text-emerald-400 font-mono">-32.8% vs cap</span>
          </div>
          <span className="text-[10px] text-zinc-500 font-mono block mt-4">
            Under budget target by $819.60
          </span>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-400 font-mono">TOTAL TOKEN VOLUME</span>
            <Layers className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-white font-mono">3.42 Billion</span>
          </div>
          <div className="flex justify-between text-[10px] font-mono text-zinc-500 mt-4">
            <span>Input: 2.35B</span>
            <span>Output: 1.07B</span>
          </div>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-400 font-mono">UNIT ECONOMICS</span>
            <Zap className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-emerald-400 font-mono">
              ${COST_DATA.costPer1kCallsUSD}
            </span>
            <span className="text-xs text-zinc-400 font-mono">/ 1k calls</span>
          </div>
          <span className="text-[10px] text-zinc-500 font-mono block mt-4">
            Benchmark: $0.18 vs industry avg $1.20
          </span>
        </div>
      </div>

      {/* Model Breakdown & Cost Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Model Breakdown Table (7 cols) */}
        <div className="lg:col-span-7 bg-zinc-900 border border-zinc-800 rounded-xl p-4 space-y-4">
          <h3 className="text-sm font-bold text-white font-mono flex items-center space-x-2">
            <Cpu className="w-4 h-4 text-indigo-400" />
            <span>Cost & Token Breakdown by Model</span>
          </h3>

          <div className="space-y-3">
            {COST_DATA.modelsUsage.map((m) => (
              <div
                key={m.model}
                className="bg-zinc-950 p-3.5 rounded-lg border border-zinc-800/80 space-y-2 font-mono text-xs"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ backgroundColor: m.color }}
                    />
                    <span className="font-bold text-white">{m.model}</span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-zinc-800 text-zinc-400">
                      {m.percentage}% of spend
                    </span>
                  </div>
                  <span className="font-bold text-white">${m.costUSD.toFixed(2)}</span>
                </div>

                {/* Progress share bar */}
                <div className="w-full bg-zinc-900 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="h-full rounded-full"
                    style={{ width: `${m.percentage}%`, backgroundColor: m.color }}
                  />
                </div>

                <div className="flex justify-between text-[10px] text-zinc-400 pt-1">
                  <span>Calls: {m.calls.toLocaleString()}</span>
                  <span>Input: {(m.inputTokens / 1e9).toFixed(2)}B tok</span>
                  <span>Output: {(m.outputTokens / 1e9).toFixed(2)}B tok</span>
                </div>
              </div>
            ))}
          </div>

          {/* Pricing Reference Note */}
          <div className="p-3 rounded-lg bg-zinc-950/70 border border-zinc-800/60 text-[11px] font-mono text-zinc-400">
            <span className="text-zinc-300 font-semibold">Gemini Reference Rates:</span>{' '}
            Flash: $0.15/1M in, $0.60/1M out • Flash-Lite: $0.075/1M in, $0.30/1M out.
          </div>
        </div>

        {/* Cost Optimization Recommendations (5 cols) */}
        <div className="lg:col-span-5 bg-zinc-900 border border-zinc-800 rounded-xl p-4 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white font-mono flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>Cost Optimization Tips</span>
            </h3>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
              Save up to $655/mo
            </span>
          </div>

          <div className="space-y-3">
            {COST_DATA.optimizationRecommendations.map((opt) => (
              <div
                key={opt.id}
                className="bg-zinc-950 p-3 rounded-lg border border-zinc-800/80 space-y-1.5"
              >
                <div className="flex items-start justify-between gap-2">
                  <h4 className="text-xs font-bold text-zinc-200 font-mono">
                    {opt.title}
                  </h4>
                  <span className="text-[10px] font-mono font-bold text-emerald-400 whitespace-nowrap">
                    +${opt.monthlySavingsUSD}/mo
                  </span>
                </div>
                <p className="text-[11px] text-zinc-400 font-mono leading-relaxed">
                  {opt.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Interactive LLM Cost & Scaling Calculator */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 space-y-4">
        <div className="flex items-center space-x-2 border-b border-zinc-800 pb-3">
          <Calculator className="w-5 h-5 text-indigo-400" />
          <h3 className="text-sm font-bold text-white font-mono">
            Interactive Production Token & Cost Calculator
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="text-xs font-mono text-zinc-400 block mb-1">
              REQUESTS PER DAY: {calcRequestsPerDay.toLocaleString()}
            </label>
            <input
              type="range"
              min="1000"
              max="500000"
              step="5000"
              value={calcRequestsPerDay}
              onChange={(e) => setCalcRequestsPerDay(Number(e.target.value))}
              className="w-full accent-indigo-500"
            />
          </div>

          <div>
            <label className="text-xs font-mono text-zinc-400 block mb-1">
              AVG PROMPT TOKENS: {calcPromptTokens}
            </label>
            <input
              type="range"
              min="100"
              max="10000"
              step="100"
              value={calcPromptTokens}
              onChange={(e) => setCalcPromptTokens(Number(e.target.value))}
              className="w-full accent-indigo-500"
            />
          </div>

          <div>
            <label className="text-xs font-mono text-zinc-400 block mb-1">
              AVG OUTPUT TOKENS: {calcOutputTokens}
            </label>
            <input
              type="range"
              min="50"
              max="4000"
              step="50"
              value={calcOutputTokens}
              onChange={(e) => setCalcOutputTokens(Number(e.target.value))}
              className="w-full accent-indigo-500"
            />
          </div>

          <div>
            <label className="text-xs font-mono text-zinc-400 block mb-1">
              ACTIVE MODEL
            </label>
            <select
              value={calcModel}
              onChange={(e) => setCalcModel(e.target.value as any)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-xs text-white font-mono focus:border-indigo-500 outline-none"
            >
              <option value="gemini-3.8-flash">gemini-3.8-flash</option>
              <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite</option>
            </select>
          </div>
        </div>

        {/* Calculator Output Banner */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-zinc-800 text-xs font-mono">
          <div className="bg-zinc-950 p-3 rounded-lg border border-zinc-800">
            <span className="text-zinc-500 block text-[10px]">ESTIMATED DAILY COST</span>
            <span className="text-xl font-bold text-white">${dailyCost.toFixed(2)}/day</span>
          </div>

          <div className="bg-zinc-950 p-3 rounded-lg border border-zinc-800">
            <span className="text-zinc-500 block text-[10px]">ESTIMATED MONTHLY COST</span>
            <span className="text-xl font-bold text-indigo-400">${monthlyCost.toFixed(2)}/mo</span>
          </div>

          <div className="bg-zinc-950 p-3 rounded-lg border border-emerald-900/60">
            <span className="text-zinc-500 block text-[10px]">SAVINGS ON FLASH-LITE</span>
            <span className="text-xl font-bold text-emerald-400">
              {calcModel === 'gemini-3.8-flash'
                ? `-$${potentialMonthlySavings.toFixed(2)}/mo (-50%)`
                : 'Optimal tier active'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
