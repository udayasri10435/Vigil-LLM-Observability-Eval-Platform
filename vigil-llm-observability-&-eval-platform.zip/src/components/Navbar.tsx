import React from 'react';
import {
  Activity,
  Layers,
  GitBranch,
  Split,
  ShieldAlert,
  Coins,
  PlayCircle,
  Terminal,
  CircleDot,
  Server,
  ChevronDown,
  Sparkles,
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedProject: string;
  setSelectedProject: (proj: string) => void;
  environment: string;
  setEnvironment: (env: string) => void;
  apiConnected: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  selectedProject,
  setSelectedProject,
  environment,
  setEnvironment,
  apiConnected,
}) => {
  const navItems = [
    { id: 'traces', label: 'Traces & Spans', icon: Layers, count: '4' },
    { id: 'prompts', label: 'Prompt Versions', icon: GitBranch, count: '4' },
    { id: 'ab-testing', label: 'A/B Testing Arena', icon: Split, badge: 'LIVE' },
    { id: 'hallucination', label: 'Hallucination & Evals', icon: ShieldAlert, badge: 'AI Judge' },
    { id: 'cost', label: 'Cost Intelligence', icon: Coins, count: '$842' },
    { id: 'playground', label: 'Playground', icon: PlayCircle },
    { id: 'sdk', label: 'SDK & Telemetry', icon: Terminal },
  ];

  return (
    <header className="border-b border-zinc-800 bg-zinc-950/90 backdrop-blur sticky top-0 z-40">
      {/* Top tier brand and meta */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14 border-b border-zinc-900">
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 via-purple-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-indigo-500/20">
                <Activity className="w-5 h-5 text-white" />
              </div>
              <div className="flex items-baseline space-x-2">
                <span className="font-bold text-lg tracking-tight text-white font-mono">VIGIL</span>
                <span className="text-xs px-2 py-0.5 rounded bg-zinc-800 text-zinc-400 font-medium">LLM Observability & Evals</span>
              </div>
            </div>

            {/* Project Switcher */}
            <div className="hidden md:flex items-center space-x-2 border-l border-zinc-800 pl-6">
              <span className="text-xs text-zinc-500 font-mono">PROJECT:</span>
              <div className="relative">
                <select
                  value={selectedProject}
                  onChange={(e) => setSelectedProject(e.target.value)}
                  className="bg-zinc-900 text-zinc-200 text-xs rounded-md border border-zinc-700/80 px-2.5 py-1 pr-7 font-mono appearance-none focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  <option value="Customer-Support-RAG">Customer-Support-RAG</option>
                  <option value="Financial-Analyst-Agent">Financial-Analyst-Agent</option>
                  <option value="Healthcare-RAG">Healthcare-RAG</option>
                  <option value="DevOps-Agent">DevOps-Agent</option>
                </select>
                <ChevronDown className="w-3.5 h-3.5 text-zinc-400 absolute right-2 top-2 pointer-events-none" />
              </div>
            </div>

            {/* Environment Switcher */}
            <div className="hidden lg:flex items-center space-x-2">
              <span className="text-xs text-zinc-500 font-mono">ENV:</span>
              <div className="relative">
                <select
                  value={environment}
                  onChange={(e) => setEnvironment(e.target.value)}
                  className="bg-zinc-900 text-emerald-400 text-xs rounded-md border border-zinc-700/80 px-2.5 py-1 pr-7 font-mono appearance-none focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  <option value="production">production (us-east-1)</option>
                  <option value="staging">staging</option>
                  <option value="canary">canary (10% traffic)</option>
                </select>
                <ChevronDown className="w-3.5 h-3.5 text-zinc-400 absolute right-2 top-2 pointer-events-none" />
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            {/* Live API Status */}
            <div className="flex items-center space-x-2 px-2.5 py-1 rounded-full bg-zinc-900 border border-zinc-800 text-xs">
              <span className="relative flex h-2 w-2">
                <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${apiConnected ? 'bg-emerald-400' : 'bg-amber-400'}`}></span>
                <span className={`relative inline-flex rounded-full h-2 w-2 ${apiConnected ? 'bg-emerald-500' : 'bg-amber-500'}`}></span>
              </span>
              <span className="text-zinc-300 font-mono text-[11px]">
                {apiConnected ? 'Gemini 3.8 Live Engine' : 'Checking Engine...'}
              </span>
            </div>

            <button
              onClick={() => setActiveTab('playground')}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium transition shadow-sm cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Test Live Run</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex space-x-1 overflow-x-auto py-1 scrollbar-none">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-md text-xs font-medium transition whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-zinc-800 text-white border-b-2 border-indigo-500 shadow-inner'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/60'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-indigo-400' : 'text-zinc-400'}`} />
                <span>{item.label}</span>
                {item.count && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                    isActive ? 'bg-indigo-950 text-indigo-300 border border-indigo-700/50' : 'bg-zinc-800 text-zinc-400'
                  }`}>
                    {item.count}
                  </span>
                )}
                {item.badge && (
                  <span className="text-[9px] px-1.5 py-0.2 rounded bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-400 border border-amber-500/30 font-mono uppercase font-bold tracking-wider">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
