import React, { useState } from 'react';
import { Terminal, Copy, Check, Code, ShieldCheck, Zap, Layers } from 'lucide-react';

export const SDKView: React.FC = () => {
  const [activeLang, setActiveLang] = useState<'python' | 'typescript' | 'otel'>('python');
  const [copied, setCopied] = useState<string | null>(null);

  const handleCopy = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  const pythonSnippet = `# 1. Install Vigil SDK
pip install vigil-ai

# 2. Instrument your application in 2 lines
from vigil import Vigil, trace

vigil = Vigil(
    api_key="vgl_live_9a8f23c91d8e",
    project="Customer-Support-RAG",
    environment="production"
)

# 3. Auto-trace chains, LLM calls, and automatic hallucination guards
@trace(name="customer_support_pipeline", evaluate_hallucination=True)
def handle_customer_query(user_query: str, retrieved_context: list[str]):
    # Your model call (Gemini, LangChain, OpenAI, etc.)
    response = call_gemini_model(
        system_instruction="Only answer using provided facts.",
        contents=f"Context: {retrieved_context}\\nQuery: {user_query}"
    )
    
    # Vigil automatically logs:
    # - Waterfall spans & retriever latency
    # - Token consumption & exact dollar cost
    # - Faithfulness score & hallucination claim breakdown
    return response`;

  const tsSnippet = `// 1. Install Vigil SDK
// npm install @vigil/sdk

import { Vigil, observe } from '@vigil/sdk';

const vigil = new Vigil({
  apiKey: process.env.VIGIL_API_KEY,
  project: 'Customer-Support-RAG',
  environment: 'production',
  guardrails: {
    faithfulnessThreshold: 0.85, // Auto-flag hallucinations below 85%
  },
});

export const processQuery = observe(
  'FinancialAnalystPipeline',
  async (query: string, secContext: string) => {
    const span = vigil.startSpan('GeminiGeneration', { model: 'gemini-3.8-flash' });
    
    const result = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: \`Context: \${secContext}\\nQuery: \${query}\`,
    });
    
    span.end({
      output: result.text,
      tokens: result.usageMetadata,
    });
    
    return result.text;
  }
);`;

  const otelSnippet = `# OpenTelemetry Collector Configuration (otel-collector-config.yaml)
receivers:
  otlp:
    protocols:
      grpc:
        endpoint: 0.0.0.0:4317
      http:
        endpoint: 0.0.0.0:4318

exporters:
  otlp/vigil:
    endpoint: "https://telemetry.vigil-ai.com:4317"
    headers:
      "x-vigil-api-key": "\${env:VIGIL_API_KEY}"
      "x-vigil-project": "Customer-Support-RAG"

service:
  pipelines:
    traces:
      receivers: [otlp]
      processors: [batch]
      exporters: [otlp/vigil]`;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-white font-mono flex items-center space-x-2">
          <Terminal className="w-5 h-5 text-indigo-400" />
          <span>SDK Integration & OpenTelemetry Exporters</span>
        </h2>
        <p className="text-xs text-zinc-400 mt-0.5">
          Drop 2 lines of code into Python, TypeScript, LangChain, or OpenTelemetry to stream traces, token costs, and hallucination scores into Vigil.
        </p>
      </div>

      {/* Language Switcher */}
      <div className="flex items-center space-x-2 border-b border-zinc-800 pb-3">
        {(['python', 'typescript', 'otel'] as const).map((lang) => (
          <button
            key={lang}
            onClick={() => setActiveLang(lang)}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono uppercase font-medium transition cursor-pointer ${
              activeLang === lang
                ? 'bg-indigo-600 text-white'
                : 'bg-zinc-900 text-zinc-400 hover:text-zinc-200'
            }`}
          >
            {lang === 'otel' ? 'OpenTelemetry (OTLP)' : lang}
          </button>
        ))}
      </div>

      {/* Code Display Card */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden shadow-xl">
        <div className="bg-zinc-950 px-4 py-2.5 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-rose-500/80" />
            <div className="w-3 h-3 rounded-full bg-amber-500/80" />
            <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
            <span className="text-xs text-zinc-400 font-mono ml-2">
              {activeLang === 'python'
                ? 'main.py'
                : activeLang === 'typescript'
                ? 'telemetry.ts'
                : 'otel-collector.yaml'}
            </span>
          </div>

          <button
            onClick={() =>
              handleCopy(
                activeLang === 'python'
                  ? pythonSnippet
                  : activeLang === 'typescript'
                  ? tsSnippet
                  : otelSnippet,
                activeLang
              )
            }
            className="flex items-center space-x-1.5 text-xs text-zinc-400 hover:text-white transition font-mono cursor-pointer"
          >
            {copied === activeLang ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Snippet</span>
              </>
            )}
          </button>
        </div>

        <pre className="p-4 text-xs font-mono text-zinc-200 overflow-x-auto bg-zinc-950/70 leading-relaxed whitespace-pre-wrap">
          {activeLang === 'python' && pythonSnippet}
          {activeLang === 'typescript' && tsSnippet}
          {activeLang === 'otel' && otelSnippet}
        </pre>
      </div>

      {/* Feature Badges */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 space-y-2">
          <div className="flex items-center space-x-2">
            <Zap className="w-4 h-4 text-indigo-400" />
            <h4 className="text-xs font-bold text-white font-mono">Zero-Overhead Tracing</h4>
          </div>
          <p className="text-xs text-zinc-400 font-mono">
            Asynchronous non-blocking background queue with micro-batching. Adds less than 1.2ms overhead to your execution latency.
          </p>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 space-y-2">
          <div className="flex items-center space-x-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <h4 className="text-xs font-bold text-white font-mono">Automated Hallucination Hooks</h4>
          </div>
          <p className="text-xs text-zinc-400 font-mono">
            Enable `evaluate_hallucination=True` to automatically decompose responses and highlight ungrounded claims in production.
          </p>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 space-y-2">
          <div className="flex items-center space-x-2">
            <Layers className="w-4 h-4 text-cyan-400" />
            <h4 className="text-xs font-bold text-white font-mono">LangChain & LlamaIndex Native</h4>
          </div>
          <p className="text-xs text-zinc-400 font-mono">
            Auto-discovers vector retrievers, tool execution spans, and recursive agent loops with zero manual instrumentation required.
          </p>
        </div>
      </div>
    </div>
  );
};
