import React, { useState } from 'react';
import {
  GitBranch,
  GitCommit,
  GitCompare,
  Plus,
  ArrowRight,
  ShieldCheck,
  Clock,
  Coins,
  Cpu,
  CheckCircle2,
  Tag,
  Copy,
  Check,
  Play,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import { PromptVersion } from '../types';

interface PromptsViewProps {
  prompts: PromptVersion[];
  onPromotePrompt: (id: string, tag: PromptVersion['tag']) => void;
  onSaveNewVersion: (newVer: PromptVersion) => void;
  onTestPrompt: (prompt: PromptVersion) => void;
}

export const PromptsView: React.FC<PromptsViewProps> = ({
  prompts,
  onPromotePrompt,
  onSaveNewVersion,
  onTestPrompt,
}) => {
  const [selectedPrompt, setSelectedPrompt] = useState<PromptVersion>(prompts[0]);
  const [comparePrompt, setComparePrompt] = useState<PromptVersion | null>(prompts[1] || null);
  const [isDiffMode, setIsDiffMode] = useState<boolean>(true);
  const [copied, setCopied] = useState(false);
  const [isCreatingNew, setIsCreatingNew] = useState(false);

  // New version form state
  const [newVersionTag, setNewVersionTag] = useState('v1.3.0');
  const [newSystemInstruction, setNewSystemInstruction] = useState(selectedPrompt?.systemInstruction || '');
  const [newTemplate, setNewTemplate] = useState(selectedPrompt?.template || '');
  const [newCommitMsg, setNewCommitMsg] = useState('');
  const [newModel, setNewModel] = useState(selectedPrompt?.model || 'gemini-3.8-flash');

  const handleCopyPrompt = () => {
    navigator.clipboard.writeText(selectedPrompt.template);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCreateCommit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommitMsg) return;

    const newObj: PromptVersion = {
      id: `pv_${Date.now()}`,
      promptSlug: selectedPrompt.promptSlug,
      name: selectedPrompt.name,
      version: newVersionTag,
      tag: 'staging',
      systemInstruction: newSystemInstruction,
      template: newTemplate,
      model: newModel,
      temperature: 0.2,
      topP: 0.9,
      commitMessage: newCommitMsg,
      author: 'You (Current Session)',
      createdAt: 'Just now',
      metrics: {
        totalRuns: 0,
        avgLatencyMs: 0,
        avgCostUSD: 0,
        faithfulnessRate: 100,
      },
      variables: ['context', 'query'],
    };

    onSaveNewVersion(newObj);
    setSelectedPrompt(newObj);
    setIsCreatingNew(false);
  };

  // Compute simple line diffs for side-by-side comparison
  const linesA = comparePrompt ? comparePrompt.template.split('\n') : [];
  const linesB = selectedPrompt.template.split('\n');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-xl font-bold text-white font-mono flex items-center space-x-2">
            <GitBranch className="w-5 h-5 text-indigo-400" />
            <span>Prompt Registry & Versioning</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Git-style semantic versioning, side-by-side diffing, one-click production promotion, and variable interpolation.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => {
              setNewSystemInstruction(selectedPrompt.systemInstruction);
              setNewTemplate(selectedPrompt.template);
              setNewCommitMsg('');
              setIsCreatingNew(true);
            }}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium transition cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Version</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Versions Timeline (4 cols) */}
        <div className="lg:col-span-4 space-y-3">
          <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-3">
            <span className="text-xs font-mono uppercase text-zinc-400 block mb-2">
              VERSION COMMIT HISTORY
            </span>

            <div className="space-y-2">
              {prompts.map((p) => {
                const isSelected = selectedPrompt.id === p.id;
                const isComparing = comparePrompt?.id === p.id;

                return (
                  <div
                    key={p.id}
                    onClick={() => {
                      if (!isSelected) {
                        setComparePrompt(selectedPrompt);
                        setSelectedPrompt(p);
                      }
                    }}
                    className={`p-3 rounded-xl border transition cursor-pointer ${
                      isSelected
                        ? 'bg-zinc-800/90 border-indigo-500 shadow-sm'
                        : 'bg-zinc-950/60 border-zinc-800/80 hover:bg-zinc-800/40'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="font-mono text-xs font-bold text-white">
                          {p.version}
                        </span>
                        <span
                          className={`text-[9px] uppercase font-mono px-1.5 py-0.2 rounded font-semibold ${
                            p.tag === 'production'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : p.tag === 'staging'
                              ? 'bg-indigo-950 text-indigo-300 border border-indigo-800'
                              : p.tag === 'canary'
                              ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                              : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                          }`}
                        >
                          {p.tag}
                        </span>
                      </div>
                      <span className="text-[10px] text-zinc-500 font-mono">
                        {p.createdAt}
                      </span>
                    </div>

                    <p className="text-xs text-zinc-300 mt-1 line-clamp-2">
                      {p.commitMessage}
                    </p>

                    <div className="mt-2.5 pt-2 border-t border-zinc-800/80 flex items-center justify-between text-[10px] font-mono text-zinc-400">
                      <span>{p.author}</span>
                      <div className="flex items-center space-x-2">
                        <span className="text-emerald-400">
                          {p.metrics.faithfulnessRate}% faithful
                        </span>
                        <span>{p.metrics.totalRuns.toLocaleString()} runs</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Version Inspector & Diff Viewer (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          {/* Version Header Card */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center space-x-2.5">
                  <h3 className="text-base font-bold text-white font-mono">
                    {selectedPrompt.name}
                  </h3>
                  <span className="text-xs px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800 font-mono">
                    {selectedPrompt.version}
                  </span>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded font-mono uppercase font-bold ${
                      selectedPrompt.tag === 'production'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : 'bg-zinc-800 text-zinc-300'
                    }`}
                  >
                    {selectedPrompt.tag}
                  </span>
                </div>
                <p className="text-xs text-zinc-400 mt-1 font-mono">
                  {selectedPrompt.commitMessage} • committed by {selectedPrompt.author}
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setIsDiffMode(!isDiffMode)}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border text-xs font-mono transition cursor-pointer ${
                    isDiffMode
                      ? 'bg-indigo-950/60 border-indigo-600 text-indigo-300'
                      : 'bg-zinc-800 border-zinc-700 text-zinc-400'
                  }`}
                >
                  <GitCompare className="w-3.5 h-3.5" />
                  <span>{isDiffMode ? 'Diff Mode ON' : 'Single View'}</span>
                </button>

                <button
                  onClick={() => onTestPrompt(selectedPrompt)}
                  className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium transition cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>Run Playground</span>
                </button>

                {selectedPrompt.tag !== 'production' && (
                  <button
                    onClick={() => onPromotePrompt(selectedPrompt.id, 'production')}
                    className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium transition cursor-pointer"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Promote to Prod</span>
                  </button>
                )}
              </div>
            </div>

            {/* Performance metrics banner */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-3 border-t border-zinc-800 text-xs font-mono">
              <div className="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800/80">
                <span className="text-zinc-500 block text-[10px]">AVG LATENCY</span>
                <span className="text-white font-bold">{selectedPrompt.metrics.avgLatencyMs} ms</span>
              </div>
              <div className="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800/80">
                <span className="text-zinc-500 block text-[10px]">AVG COST PER CALL</span>
                <span className="text-white font-bold">${selectedPrompt.metrics.avgCostUSD.toFixed(6)}</span>
              </div>
              <div className="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800/80">
                <span className="text-zinc-500 block text-[10px]">FAITHFULNESS SCORE</span>
                <span className="text-emerald-400 font-bold">{selectedPrompt.metrics.faithfulnessRate}%</span>
              </div>
              <div className="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800/80">
                <span className="text-zinc-500 block text-[10px]">DEFAULT MODEL</span>
                <span className="text-zinc-300 font-bold">{selectedPrompt.model}</span>
              </div>
            </div>
          </div>

          {/* Template Variables Strip */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-3 flex items-center space-x-3 text-xs font-mono">
            <span className="text-zinc-400">DETECTED TEMPLATE VARIABLES:</span>
            <div className="flex items-center space-x-2">
              {selectedPrompt.variables.map((v) => (
                <span
                  key={v}
                  className="px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800 text-[11px]"
                >
                  {`{{${v}}}`}
                </span>
              ))}
            </div>
          </div>

          {/* Diff View or Single View */}
          {isDiffMode && comparePrompt && comparePrompt.id !== selectedPrompt.id ? (
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3 text-xs font-mono">
                <span className="text-rose-400 flex items-center space-x-1">
                  <span>- Base: {comparePrompt.version} ({comparePrompt.tag})</span>
                </span>
                <ArrowRight className="w-3.5 h-3.5 text-zinc-500" />
                <span className="text-emerald-400 flex items-center space-x-1">
                  <span>+ Target: {selectedPrompt.version} ({selectedPrompt.tag})</span>
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <span className="text-[11px] font-mono text-zinc-400 block mb-1">
                    {comparePrompt.version} (PREVIOUS)
                  </span>
                  <pre className="bg-zinc-950 p-3 rounded-lg border border-rose-950 text-zinc-300 text-xs font-mono overflow-x-auto whitespace-pre-wrap min-h-[220px]">
                    {comparePrompt.template}
                  </pre>
                </div>
                <div>
                  <span className="text-[11px] font-mono text-zinc-400 block mb-1">
                    {selectedPrompt.version} (CURRENT)
                  </span>
                  <pre className="bg-zinc-950 p-3 rounded-lg border border-emerald-950 text-emerald-200 text-xs font-mono overflow-x-auto whitespace-pre-wrap min-h-[220px]">
                    {selectedPrompt.template}
                  </pre>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 space-y-4">
              <div>
                <span className="text-xs font-mono text-zinc-400 block mb-1">
                  SYSTEM INSTRUCTION
                </span>
                <pre className="bg-zinc-950 p-3 rounded-lg border border-zinc-800 text-zinc-300 text-xs font-mono overflow-x-auto whitespace-pre-wrap">
                  {selectedPrompt.systemInstruction || 'No system instruction defined.'}
                </pre>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-mono text-zinc-400">
                    USER PROMPT TEMPLATE
                  </span>
                  <button
                    onClick={handleCopyPrompt}
                    className="text-xs text-zinc-400 hover:text-zinc-200 flex items-center space-x-1 transition cursor-pointer"
                  >
                    {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <pre className="bg-zinc-950 p-3 rounded-lg border border-zinc-800 text-zinc-200 text-xs font-mono overflow-x-auto whitespace-pre-wrap">
                  {selectedPrompt.template}
                </pre>
              </div>
            </div>
          )}

          {/* New Version Modal Form */}
          {isCreatingNew && (
            <div className="bg-zinc-900 border-2 border-indigo-500 rounded-xl p-5 space-y-4 shadow-xl">
              <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                <h4 className="text-sm font-bold text-white font-mono flex items-center space-x-2">
                  <Plus className="w-4 h-4 text-indigo-400" />
                  <span>Create & Commit New Prompt Version</span>
                </h4>
                <button
                  onClick={() => setIsCreatingNew(false)}
                  className="text-zinc-500 hover:text-zinc-300 text-xs cursor-pointer"
                >
                  Cancel
                </button>
              </div>

              <form onSubmit={handleCreateCommit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-mono text-zinc-400 block mb-1">
                      VERSION TAG
                    </label>
                    <input
                      type="text"
                      value={newVersionTag}
                      onChange={(e) => setNewVersionTag(e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:border-indigo-500 outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-xs font-mono text-zinc-400 block mb-1">
                      TARGET MODEL
                    </label>
                    <select
                      value={newModel}
                      onChange={(e) => setNewModel(e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:border-indigo-500 outline-none"
                    >
                      <option value="gemini-3.8-flash">gemini-3.8-flash (General & Reasoning)</option>
                      <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (Cost-Optimized)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-mono text-zinc-400 block mb-1">
                    SYSTEM INSTRUCTION
                  </label>
                  <textarea
                    rows={3}
                    value={newSystemInstruction}
                    onChange={(e) => setNewSystemInstruction(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2.5 text-xs text-white font-mono focus:border-indigo-500 outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-mono text-zinc-400 block mb-1">
                    PROMPT TEMPLATE (use {'{{query}}'}, {'{{context}}'})
                  </label>
                  <textarea
                    rows={4}
                    value={newTemplate}
                    onChange={(e) => setNewTemplate(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2.5 text-xs text-white font-mono focus:border-indigo-500 outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="text-xs font-mono text-zinc-400 block mb-1">
                    COMMIT MESSAGE / CHANGELOG
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Add chain-of-thought grounding to cut hallucinations"
                    value={newCommitMsg}
                    onChange={(e) => setNewCommitMsg(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:border-indigo-500 outline-none"
                    required
                  />
                </div>

                <div className="flex justify-end space-x-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsCreatingNew(false)}
                    className="px-3 py-1.5 rounded-lg border border-zinc-800 text-zinc-400 hover:text-white text-xs font-mono cursor-pointer"
                  >
                    Discard
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium font-mono cursor-pointer"
                  >
                    Commit Version
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
