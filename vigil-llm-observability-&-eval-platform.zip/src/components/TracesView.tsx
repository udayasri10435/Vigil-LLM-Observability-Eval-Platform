import React, { useState } from 'react';
import {
  Layers,
  Search,
  Filter,
  Clock,
  Coins,
  Cpu,
  ShieldCheck,
  ShieldAlert,
  ChevronRight,
  ExternalLink,
  Copy,
  Check,
  Terminal,
  Play,
  Share2,
  RefreshCw,
  AlertTriangle,
  FileText,
} from 'lucide-react';
import { Trace, Span } from '../types';

interface TracesViewProps {
  traces: Trace[];
  onOpenPlaygroundWithTrace?: (trace: Trace) => void;
  onRunHallucinationScan?: (context: string, prompt: string, output: string) => void;
}

export const TracesView: React.FC<TracesViewProps> = ({
  traces,
  onOpenPlaygroundWithTrace,
  onRunHallucinationScan,
}) => {
  const [selectedTrace, setSelectedTrace] = useState<Trace>(traces[0]);
  const [selectedSpan, setSelectedSpan] = useState<Span | null>(traces[0]?.rootSpan || null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'success' | 'warning' | 'error'>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filteredTraces = traces.filter((t) => {
    const matchesQuery =
      t.sessionTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase())) ||
      t.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || t.status === statusFilter;
    return matchesQuery && matchesStatus;
  });

  const getSpanTypeColor = (type: Span['type']) => {
    switch (type) {
      case 'chain':
        return 'bg-purple-900/40 text-purple-300 border-purple-700/60';
      case 'llm':
        return 'bg-indigo-900/40 text-indigo-300 border-indigo-700/60';
      case 'retriever':
        return 'bg-emerald-900/40 text-emerald-300 border-emerald-700/60';
      case 'guardrail':
        return 'bg-amber-900/40 text-amber-300 border-amber-700/60';
      case 'tool':
        return 'bg-cyan-900/40 text-cyan-300 border-cyan-700/60';
      default:
        return 'bg-zinc-800 text-zinc-300 border-zinc-700';
    }
  };

  // Flatten spans for waterfall timeline
  const getAllSpans = (span: Span, depth = 0): { span: Span; depth: number }[] => {
    const result: { span: Span; depth: number }[] = [{ span, depth }];
    if (span.children) {
      for (const child of span.children) {
        result.push(...getAllSpans(child, depth + 1));
      }
    }
    return result;
  };

  const allWaterfallSpans = selectedTrace ? getAllSpans(selectedTrace.rootSpan) : [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Metrics Summary Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-zinc-900/70 border border-zinc-800 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-400 font-mono">TOTAL TRACES (24h)</span>
            <Layers className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-white font-mono">{traces.length * 1240}</span>
            <span className="text-xs text-emerald-400 font-mono">+12.4%</span>
          </div>
        </div>

        <div className="bg-zinc-900/70 border border-zinc-800 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-400 font-mono">AVG LATENCY (P95)</span>
            <Clock className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-white font-mono">824ms</span>
            <span className="text-xs text-zinc-400 font-mono">TTFT: 190ms</span>
          </div>
        </div>

        <div className="bg-zinc-900/70 border border-zinc-800 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-400 font-mono">FAITHFULNESS PASS RATE</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-emerald-400 font-mono">94.8%</span>
            <span className="text-xs text-amber-400 font-mono">5.2% flagged</span>
          </div>
        </div>

        <div className="bg-zinc-900/70 border border-zinc-800 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-400 font-mono">ESTIMATED SPEND (USD)</span>
            <Coins className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-white font-mono">$0.00136</span>
            <span className="text-xs text-zinc-400 font-mono">~3.2M tokens</span>
          </div>
        </div>
      </div>

      {/* Main Split: Trace list on left, Waterfall / Inspector on right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Trace List (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Filter Bar */}
          <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-3 space-y-2">
            <div className="relative">
              <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search trace ID, session, tags..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-indigo-500 font-mono"
              />
            </div>

            <div className="flex items-center space-x-1.5">
              {(['all', 'success', 'warning', 'error'] as const).map((st) => (
                <button
                  key={st}
                  onClick={() => setStatusFilter(st)}
                  className={`px-2.5 py-1 rounded text-[11px] font-mono capitalize transition cursor-pointer ${
                    statusFilter === st
                      ? 'bg-indigo-600 text-white font-medium'
                      : 'bg-zinc-800/80 text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>

          {/* Trace Cards */}
          <div className="space-y-2.5 max-h-[720px] overflow-y-auto pr-1">
            {filteredTraces.map((trace) => {
              const isSelected = selectedTrace?.id === trace.id;
              return (
                <div
                  key={trace.id}
                  onClick={() => {
                    setSelectedTrace(trace);
                    setSelectedSpan(trace.rootSpan);
                  }}
                  className={`p-3.5 rounded-xl border transition cursor-pointer relative ${
                    isSelected
                      ? 'bg-zinc-900 border-indigo-500 shadow-md shadow-indigo-500/10'
                      : 'bg-zinc-900/50 border-zinc-800/80 hover:bg-zinc-900/80 hover:border-zinc-700'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-mono text-xs font-semibold text-zinc-200">
                          {trace.id}
                        </span>
                        <span
                          className={`text-[10px] px-1.5 py-0.5 rounded font-mono font-medium ${
                            trace.status === 'success'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : trace.status === 'warning'
                              ? 'bg-amber-950 text-amber-300 border border-amber-800'
                              : 'bg-rose-950 text-rose-300 border border-rose-800'
                          }`}
                        >
                          {trace.status.toUpperCase()}
                        </span>
                        <span className="text-[10px] text-zinc-500 font-mono">
                          {trace.timestamp}
                        </span>
                      </div>
                      <h4 className="text-xs font-medium text-zinc-300 mt-1 line-clamp-1">
                        {trace.sessionTitle}
                      </h4>
                    </div>

                    <div className="text-right">
                      <div className="text-xs font-mono font-medium text-white">
                        {trace.totalDurationMs}ms
                      </div>
                      <div className="text-[10px] font-mono text-zinc-400">
                        ${trace.totalCostUSD.toFixed(6)}
                      </div>
                    </div>
                  </div>

                  {/* Metadata Row */}
                  <div className="mt-3 flex items-center justify-between text-[11px] pt-2 border-t border-zinc-800/60">
                    <div className="flex items-center space-x-1.5">
                      <Cpu className="w-3 h-3 text-zinc-500" />
                      <span className="text-zinc-400 font-mono text-[10px]">{trace.model}</span>
                    </div>

                    {trace.faithfulnessScore !== undefined && (
                      <div className="flex items-center space-x-1 font-mono text-[10px]">
                        {trace.faithfulnessScore >= 90 ? (
                          <ShieldCheck className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <ShieldAlert className="w-3 h-3 text-amber-400" />
                        )}
                        <span
                          className={
                            trace.faithfulnessScore >= 90
                              ? 'text-emerald-400'
                              : 'text-amber-400 font-bold'
                          }
                        >
                          Faithfulness: {trace.faithfulnessScore}%
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Tags */}
                  <div className="mt-2 flex flex-wrap gap-1">
                    {trace.tags.map((tag) => (
                      <span
                        key={tag}
                        className="text-[9px] px-1.5 py-0.2 rounded bg-zinc-800/90 text-zinc-400 font-mono"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Waterfall Gantt Chart & Span Detail Inspector (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {selectedTrace ? (
            <>
              {/* Trace Header & Actions */}
              <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center space-x-2">
                      <h3 className="text-base font-semibold text-white font-mono">
                        {selectedTrace.sessionTitle}
                      </h3>
                      <button
                        onClick={() => handleCopy(selectedTrace.id, selectedTrace.id)}
                        className="p-1 rounded text-zinc-500 hover:text-zinc-200 transition cursor-pointer"
                        title="Copy Trace ID"
                      >
                        {copiedId === selectedTrace.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                    <div className="flex items-center space-x-3 mt-1 text-xs text-zinc-400 font-mono">
                      <span>ID: {selectedTrace.id}</span>
                      <span>•</span>
                      <span>ENV: {selectedTrace.environment}</span>
                      <span>•</span>
                      <span>USER: {selectedTrace.userId}</span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    {onRunHallucinationScan && (
                      <button
                        onClick={() => {
                          const llmSpan = allWaterfallSpans.find((s) => s.span.type === 'llm');
                          const retrieverSpan = allWaterfallSpans.find((s) => s.span.type === 'retriever');
                          const context = retrieverSpan?.span?.output?.excerpts?.join('\n') || 'Retrieved context facts';
                          const prompt = typeof llmSpan?.span?.input === 'string' ? llmSpan.span.input : JSON.stringify(llmSpan?.span?.input || {});
                          const output = typeof llmSpan?.span?.output === 'string' ? llmSpan.span.output : JSON.stringify(llmSpan?.span?.output || {});
                          onRunHallucinationScan(context, prompt, output);
                        }}
                        className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg bg-amber-600/20 text-amber-300 border border-amber-500/40 text-xs font-medium hover:bg-amber-600/30 transition cursor-pointer"
                      >
                        <ShieldAlert className="w-3.5 h-3.5" />
                        <span>Audit Hallucination</span>
                      </button>
                    )}

                    {onOpenPlaygroundWithTrace && (
                      <button
                        onClick={() => onOpenPlaygroundWithTrace(selectedTrace)}
                        className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium transition cursor-pointer"
                      >
                        <Play className="w-3.5 h-3.5" />
                        <span>Replay</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Key Metrics Pill Row */}
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 mt-4 pt-3 border-t border-zinc-800 text-xs font-mono">
                  <div className="bg-zinc-950 p-2 rounded-lg border border-zinc-800/80">
                    <span className="text-zinc-500 block text-[10px]">TOTAL DURATION</span>
                    <span className="text-white font-bold">{selectedTrace.totalDurationMs} ms</span>
                  </div>
                  <div className="bg-zinc-950 p-2 rounded-lg border border-zinc-800/80">
                    <span className="text-zinc-500 block text-[10px]">TOTAL COST</span>
                    <span className="text-white font-bold">${selectedTrace.totalCostUSD.toFixed(6)}</span>
                  </div>
                  <div className="bg-zinc-950 p-2 rounded-lg border border-zinc-800/80">
                    <span className="text-zinc-500 block text-[10px]">TOTAL TOKENS</span>
                    <span className="text-white font-bold">{selectedTrace.totalTokens.toLocaleString()}</span>
                  </div>
                  <div className="bg-zinc-950 p-2 rounded-lg border border-zinc-800/80">
                    <span className="text-zinc-500 block text-[10px]">FAITHFULNESS</span>
                    <span
                      className={`font-bold ${
                        (selectedTrace.faithfulnessScore || 0) >= 90
                          ? 'text-emerald-400'
                          : 'text-amber-400'
                      }`}
                    >
                      {selectedTrace.faithfulnessScore ?? 'N/A'}%
                    </span>
                  </div>
                </div>
              </div>

              {/* Waterfall Execution Graph (LangSmith style) */}
              <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-xs font-mono uppercase tracking-wider text-zinc-400 flex items-center space-x-1.5">
                    <Layers className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Execution Spans Waterfall</span>
                  </h4>
                  <span className="text-[11px] text-zinc-500 font-mono">
                    {allWaterfallSpans.length} spans • click to inspect
                  </span>
                </div>

                {/* Timeline scale */}
                <div className="space-y-2">
                  <div className="flex justify-between text-[10px] text-zinc-500 font-mono border-b border-zinc-800 pb-1">
                    <span>0ms</span>
                    <span>{Math.round(selectedTrace.totalDurationMs / 2)}ms</span>
                    <span>{selectedTrace.totalDurationMs}ms</span>
                  </div>

                  {/* Spans */}
                  <div className="space-y-1.5">
                    {allWaterfallSpans.map(({ span, depth }) => {
                      const isSpanSelected = selectedSpan?.id === span.id;
                      const totalMs = Math.max(selectedTrace.totalDurationMs, 1);
                      const leftPercent = (span.startTime / totalMs) * 100;
                      const widthPercent = Math.max((span.durationMs / totalMs) * 100, 4);

                      return (
                        <div
                          key={span.id}
                          onClick={() => setSelectedSpan(span)}
                          className={`group p-2 rounded-lg transition border cursor-pointer ${
                            isSpanSelected
                              ? 'bg-zinc-800/90 border-indigo-500'
                              : 'bg-zinc-950/60 border-zinc-800/60 hover:bg-zinc-800/40'
                          }`}
                        >
                          <div className="flex items-center justify-between text-xs mb-1.5">
                            <div className="flex items-center space-x-2">
                              <span style={{ marginLeft: `${depth * 12}px` }} className="text-zinc-600">
                                └
                              </span>
                              <span
                                className={`text-[10px] uppercase font-mono px-1.5 py-0.2 rounded border ${getSpanTypeColor(
                                  span.type
                                )}`}
                              >
                                {span.type}
                              </span>
                              <span className="font-mono text-zinc-200 font-medium truncate max-w-[220px]">
                                {span.name}
                              </span>
                            </div>
                            <div className="flex items-center space-x-2 text-[11px] font-mono text-zinc-400">
                              <span>{span.durationMs}ms</span>
                              {span.tokens && (
                                <span className="text-zinc-500">
                                  ({span.tokens.total} tok)
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Gantt Bar */}
                          <div className="w-full bg-zinc-900 rounded-full h-2 overflow-hidden relative">
                            <div
                              className={`h-full rounded-full transition-all ${
                                span.status === 'error'
                                  ? 'bg-rose-500'
                                  : span.status === 'warning'
                                  ? 'bg-amber-500'
                                  : span.type === 'llm'
                                  ? 'bg-indigo-500'
                                  : span.type === 'retriever'
                                  ? 'bg-emerald-500'
                                  : 'bg-purple-500'
                              }`}
                              style={{
                                marginLeft: `${Math.min(leftPercent, 95)}%`,
                                width: `${Math.min(widthPercent, 100 - leftPercent)}%`,
                              }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Selected Span Detailed Inspector */}
              {selectedSpan && (
                <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 space-y-4">
                  <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                    <div className="flex items-center space-x-2">
                      <span
                        className={`text-[11px] uppercase font-mono px-2 py-0.5 rounded border ${getSpanTypeColor(
                          selectedSpan.type
                        )}`}
                      >
                        {selectedSpan.type}
                      </span>
                      <h4 className="text-sm font-semibold text-white font-mono">
                        {selectedSpan.name}
                      </h4>
                    </div>
                    <span className="text-xs text-zinc-400 font-mono">
                      Span ID: {selectedSpan.id}
                    </span>
                  </div>

                  {/* Input block */}
                  <div>
                    <span className="text-[11px] font-mono text-zinc-400 block mb-1">
                      INPUT PAYLOAD
                    </span>
                    <pre className="bg-zinc-950 p-3 rounded-lg border border-zinc-800 text-zinc-300 text-xs font-mono overflow-x-auto max-h-48 whitespace-pre-wrap">
                      {typeof selectedSpan.input === 'object'
                        ? JSON.stringify(selectedSpan.input, null, 2)
                        : selectedSpan.input}
                    </pre>
                  </div>

                  {/* Output block */}
                  <div>
                    <span className="text-[11px] font-mono text-zinc-400 block mb-1">
                      OUTPUT / EVALUATION
                    </span>
                    <pre
                      className={`p-3 rounded-lg border text-xs font-mono overflow-x-auto max-h-56 whitespace-pre-wrap ${
                        selectedSpan.status === 'warning'
                          ? 'bg-amber-950/20 border-amber-800/80 text-amber-200'
                          : selectedSpan.status === 'error'
                          ? 'bg-rose-950/20 border-rose-800/80 text-rose-200'
                          : 'bg-zinc-950 border-zinc-800 text-zinc-300'
                      }`}
                    >
                      {typeof selectedSpan.output === 'object'
                        ? JSON.stringify(selectedSpan.output, null, 2)
                        : selectedSpan.output}
                    </pre>
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-12 text-center text-zinc-500">
              Select a trace from the left panel to inspect execution waterfall spans.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
