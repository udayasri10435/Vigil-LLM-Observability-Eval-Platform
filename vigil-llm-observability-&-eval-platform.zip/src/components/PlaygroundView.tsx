import React, { useState } from 'react';
import {
  PlayCircle,
  Clock,
  Coins,
  Cpu,
  RotateCcw,
  Sparkles,
  Layers,
  ShieldAlert,
  Save,
  Check,
} from 'lucide-react';
import { Trace } from '../types';

interface PlaygroundViewProps {
  onTraceCreated?: (trace: Trace) => void;
  onAuditHallucination?: (context: string, prompt: string, output: string) => void;
  initialPromptText?: string;
  initialSystemText?: string;
}

export const PlaygroundView: React.FC<PlaygroundViewProps> = ({
  onTraceCreated,
  onAuditHallucination,
  initialPromptText,
  initialSystemText,
}) => {
  const [model, setModel] = useState<'gemini-3.8-flash' | 'gemini-3.1-flash-lite'>('gemini-3.8-flash');
  const [temperature, setTemperature] = useState(0.7);
  const [systemInstruction, setSystemInstruction] = useState(
    initialSystemText ||
      'You are a senior financial analyst and compliance auditor. Only answer using provided facts.'
  );
  const [promptTemplate, setPromptTemplate] = useState(
    initialPromptText ||
      `Reference Context:
{{context}}

Question:
{{query}}

Provide a concise, factual answer.`
  );

  // Dynamic variable map
  const [variables, setVariables] = useState<Record<string, string>>({
    context:
      'Acme Corp Q3 2025 revenue came in at $840M with gross profit of $386M (45.9% margin). Operating cash flow was $98M.',
    query: 'What was Acme Corp gross profit margin in Q3 2025?',
  });

  const [isRunning, setIsRunning] = useState(false);
  const [responseOutput, setResponseOutput] = useState<string | null>(null);
  const [stats, setStats] = useState<{
    latencyMs: number;
    inputTokens: number;
    outputTokens: number;
    totalTokens: number;
    cost: number;
  } | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [savedAsTrace, setSavedAsTrace] = useState(false);

  // Extract variables like {{var}} from promptTemplate
  const detectedVars = Array.from(
    new Set((promptTemplate.match(/{{\s*(\w+)\s*}}/g) || []).map((m) => m.replace(/[{}]/g, '').trim()))
  );

  const handleRun = async () => {
    setIsRunning(true);
    setErrorMsg(null);
    setSavedAsTrace(false);

    try {
      const res = await fetch('/api/run-prompt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: promptTemplate,
          systemInstruction,
          model,
          temperature,
          variables,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Execution failed');
      }

      const data = await res.json();
      setResponseOutput(data.text);
      setStats({
        latencyMs: data.latencyMs,
        inputTokens: data.inputTokens,
        outputTokens: data.outputTokens,
        totalTokens: data.totalTokens,
        cost: data.cost,
      });
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Failed to execute prompt in playground');
    } finally {
      setIsRunning(false);
    }
  };

  const handleSaveToTraces = () => {
    if (!responseOutput || !stats) return;

    const newTrace: Trace = {
      id: `tr_${Math.random().toString(36).substring(2, 10)}`,
      sessionTitle: `Playground Run (${variables.query ? variables.query.slice(0, 32) : 'Ad-hoc'})`,
      environment: 'staging',
      projectName: 'Playground-Runs',
      timestamp: 'Just now',
      totalDurationMs: stats.latencyMs,
      totalCostUSD: stats.cost,
      totalTokens: stats.totalTokens,
      status: 'success',
      model,
      tags: ['playground', 'ad-hoc'],
      userId: 'usr_current_engineer',
      rootSpan: {
        id: `span_${Date.now()}`,
        name: 'PlaygroundGeneration',
        type: 'llm',
        startTime: 0,
        durationMs: stats.latencyMs,
        status: 'success',
        model,
        input: { prompt: promptTemplate, variables, systemInstruction },
        output: responseOutput,
        tokens: {
          prompt: stats.inputTokens,
          completion: stats.outputTokens,
          total: stats.totalTokens,
        },
        cost: stats.cost,
      },
    };

    if (onTraceCreated) {
      onTraceCreated(newTrace);
      setSavedAsTrace(true);
      setTimeout(() => setSavedAsTrace(false), 2500);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white font-mono flex items-center space-x-2">
            <PlayCircle className="w-5 h-5 text-indigo-400" />
            <span>Interactive Prompt & Model Playground</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Test prompt templates with live variable interpolation, inspect token counts & latency, and record live traces.
          </p>
        </div>

        {/* Model & Config Pill */}
        <div className="flex items-center space-x-3 text-xs font-mono">
          <div className="flex items-center space-x-1.5 bg-zinc-900 border border-zinc-800 px-3 py-1.5 rounded-lg">
            <Cpu className="w-3.5 h-3.5 text-indigo-400" />
            <select
              value={model}
              onChange={(e) => setModel(e.target.value as any)}
              className="bg-transparent text-zinc-200 outline-none cursor-pointer"
            >
              <option value="gemini-3.8-flash">gemini-3.8-flash (Reasoning)</option>
              <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (Cost-Opt)</option>
            </select>
          </div>

          <div className="flex items-center space-x-2 bg-zinc-900 border border-zinc-800 px-3 py-1.5 rounded-lg">
            <span className="text-zinc-400">Temp:</span>
            <input
              type="number"
              min="0"
              max="2"
              step="0.1"
              value={temperature}
              onChange={(e) => setTemperature(parseFloat(e.target.value))}
              className="w-12 bg-zinc-950 border border-zinc-700 rounded px-1.5 py-0.5 text-center text-white"
            >
            </input>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Inputs & Variables (6 cols) */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 space-y-2">
            <label className="text-xs font-mono uppercase text-zinc-400 block font-semibold">
              SYSTEM INSTRUCTION
            </label>
            <textarea
              rows={2}
              value={systemInstruction}
              onChange={(e) => setSystemInstruction(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2.5 text-xs text-zinc-200 font-mono focus:border-indigo-500 outline-none resize-none"
              placeholder="System prompt / persona..."
            />
          </div>

          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 space-y-2">
            <label className="text-xs font-mono uppercase text-zinc-400 block font-semibold">
              PROMPT TEMPLATE (USE {'{{var}}'} FOR PLACEHOLDERS)
            </label>
            <textarea
              rows={5}
              value={promptTemplate}
              onChange={(e) => setPromptTemplate(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2.5 text-xs text-zinc-200 font-mono focus:border-indigo-500 outline-none resize-none leading-relaxed"
              placeholder="e.g. Reference context: {{context}}\nUser question: {{query}}"
            />
          </div>

          {/* Variables Table */}
          {detectedVars.length > 0 && (
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 space-y-3">
              <span className="text-xs font-mono uppercase text-zinc-400 font-semibold block">
                TEMPLATE VARIABLES ({detectedVars.length})
              </span>

              <div className="space-y-2">
                {detectedVars.map((v) => (
                  <div key={v} className="space-y-1">
                    <span className="text-[11px] font-mono text-indigo-400 font-medium">
                      {`{{${v}}}`}
                    </span>
                    <input
                      type="text"
                      value={variables[v] || ''}
                      onChange={(e) =>
                        setVariables({ ...variables, [v]: e.target.value })
                      }
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-1.5 text-xs text-zinc-200 font-mono focus:border-indigo-500 outline-none"
                      placeholder={`Enter value for ${v}...`}
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          <button
            onClick={handleRun}
            disabled={isRunning || !promptTemplate}
            className={`w-full flex items-center justify-center space-x-2 px-4 py-2.5 rounded-lg font-medium text-xs font-mono transition cursor-pointer ${
              isRunning
                ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/20'
            }`}
          >
            {isRunning ? (
              <>
                <RotateCcw className="w-4 h-4 animate-spin" />
                <span>Generating with Gemini API...</span>
              </>
            ) : (
              <>
                <PlayCircle className="w-4 h-4" />
                <span>Execute Prompt</span>
              </>
            )}
          </button>
        </div>

        {/* Right: Output & Live Telemetry (6 cols) */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
              <span className="text-xs font-mono uppercase text-zinc-400 font-semibold">
                MODEL RESPONSE
              </span>

              {stats && (
                <div className="flex items-center space-x-2">
                  {onAuditHallucination && (
                    <button
                      onClick={() =>
                        onAuditHallucination(
                          variables.context || '',
                          variables.query || promptTemplate,
                          responseOutput || ''
                        )
                      }
                      className="flex items-center space-x-1 text-[11px] font-mono px-2 py-1 rounded bg-amber-950/80 text-amber-300 border border-amber-800 hover:bg-amber-900 transition cursor-pointer"
                    >
                      <ShieldAlert className="w-3 h-3" />
                      <span>Audit Hallucination</span>
                    </button>
                  )}

                  <button
                    onClick={handleSaveToTraces}
                    disabled={savedAsTrace}
                    className="flex items-center space-x-1 text-[11px] font-mono px-2 py-1 rounded bg-indigo-950 text-indigo-300 border border-indigo-800 hover:bg-indigo-900 transition cursor-pointer"
                  >
                    {savedAsTrace ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span>Logged to Traces!</span>
                      </>
                    ) : (
                      <>
                        <Save className="w-3 h-3" />
                        <span>Log as Trace</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>

            <div className="bg-zinc-950 p-3.5 rounded-lg border border-zinc-800 text-xs font-mono text-zinc-200 whitespace-pre-wrap min-h-[220px] leading-relaxed">
              {responseOutput ? (
                responseOutput
              ) : (
                <span className="text-zinc-600">
                  Run a prompt to see live generation output, token consumption, and latency metrics...
                </span>
              )}
            </div>

            {errorMsg && (
              <div className="p-3 rounded-lg bg-rose-950/40 border border-rose-800 text-rose-300 text-xs font-mono">
                {errorMsg}
              </div>
            )}

            {/* Telemetry Strip */}
            {stats && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-zinc-800 text-xs font-mono">
                <div className="bg-zinc-950 p-2 rounded-lg border border-zinc-800">
                  <span className="text-zinc-500 block text-[10px]">LATENCY</span>
                  <span className="text-white font-bold">{stats.latencyMs} ms</span>
                </div>
                <div className="bg-zinc-950 p-2 rounded-lg border border-zinc-800">
                  <span className="text-zinc-500 block text-[10px]">INPUT TOKENS</span>
                  <span className="text-zinc-300 font-bold">{stats.inputTokens}</span>
                </div>
                <div className="bg-zinc-950 p-2 rounded-lg border border-zinc-800">
                  <span className="text-zinc-500 block text-[10px]">OUTPUT TOKENS</span>
                  <span className="text-zinc-300 font-bold">{stats.outputTokens}</span>
                </div>
                <div className="bg-zinc-950 p-2 rounded-lg border border-zinc-800">
                  <span className="text-zinc-500 block text-[10px]">EST. COST</span>
                  <span className="text-amber-400 font-bold">${stats.cost.toFixed(6)}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
