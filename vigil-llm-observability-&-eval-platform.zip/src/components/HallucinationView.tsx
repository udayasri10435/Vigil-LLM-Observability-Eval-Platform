import React, { useState } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Sparkles,
  BookOpen,
  ArrowRight,
  FileCheck,
  RefreshCw,
  Copy,
  Check,
} from 'lucide-react';
import { PRESET_HALLUCINATION_TEST } from '../data/mockData';
import { HallucinationEvalResult } from '../types';

interface HallucinationViewProps {
  initialContext?: string;
  initialPrompt?: string;
  initialOutput?: string;
}

export const HallucinationView: React.FC<HallucinationViewProps> = ({
  initialContext,
  initialPrompt,
  initialOutput,
}) => {
  const [context, setContext] = useState(initialContext || PRESET_HALLUCINATION_TEST.context);
  const [prompt, setPrompt] = useState(initialPrompt || PRESET_HALLUCINATION_TEST.prompt);
  const [output, setOutput] = useState(initialOutput || PRESET_HALLUCINATION_TEST.output);

  const [isRunning, setIsRunning] = useState(false);
  const [result, setResult] = useState<HallucinationEvalResult | null>(
    PRESET_HALLUCINATION_TEST.knownResult
  );
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [copiedRewrite, setCopiedRewrite] = useState(false);

  const handleRunEvaluation = async () => {
    if (!context || !output) return;

    setIsRunning(true);
    setErrorMsg(null);

    try {
      const res = await fetch('/api/eval/hallucination', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ context, prompt, output }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Evaluation failed');
      }

      const data = await res.json();
      setResult(data);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Failed to complete hallucination evaluation');
    } finally {
      setIsRunning(false);
    }
  };

  const handleCopyRewrite = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedRewrite(true);
    setTimeout(() => setCopiedRewrite(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white font-mono flex items-center space-x-2">
            <ShieldAlert className="w-5 h-5 text-amber-400" />
            <span>Automated Hallucination & Faithfulness Detection</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Real-time LLM-as-a-Judge audit. Decomposes outputs into atomic claims, verifies grounding against source context, and highlights contradictions.
          </p>
        </div>

        <button
          onClick={() => {
            setContext(PRESET_HALLUCINATION_TEST.context);
            setPrompt(PRESET_HALLUCINATION_TEST.prompt);
            setOutput(PRESET_HALLUCINATION_TEST.output);
            setResult(PRESET_HALLUCINATION_TEST.knownResult);
          }}
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-mono transition cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Sample Case</span>
        </button>
      </div>

      {/* Input Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Source Context */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-mono uppercase text-zinc-400 font-semibold flex items-center space-x-1.5">
              <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
              <span>REFERENCE CONTEXT (GROUND TRUTH DOCUMENTS)</span>
            </label>
            <span className="text-[10px] text-zinc-500 font-mono">
              {context.split(' ').length} words
            </span>
          </div>
          <textarea
            rows={6}
            value={context}
            onChange={(e) => setContext(e.target.value)}
            className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-xs text-zinc-200 font-mono focus:border-indigo-500 outline-none resize-none leading-relaxed"
            placeholder="Paste verified factual source document or retrieved RAG context here..."
          />
        </div>

        {/* Model Output to evaluate */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-mono uppercase text-zinc-400 font-semibold flex items-center space-x-1.5">
              <FileCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>GENERATED LLM OUTPUT (TO AUDIT)</span>
            </label>
            <span className="text-[10px] text-zinc-500 font-mono">
              {output.split(' ').length} words
            </span>
          </div>
          <textarea
            rows={6}
            value={output}
            onChange={(e) => setOutput(e.target.value)}
            className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-xs text-zinc-200 font-mono focus:border-amber-500 outline-none resize-none leading-relaxed"
            placeholder="Paste the generated response to check for hallucinations..."
          />
        </div>
      </div>

      {/* Action Strip */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center space-x-2 text-xs font-mono text-zinc-400">
          <Sparkles className="w-4 h-4 text-indigo-400" />
          <span>Evaluator: Gemini 3.8 Flash Judge with strict claim extraction schema</span>
        </div>

        <button
          onClick={handleRunEvaluation}
          disabled={isRunning || !context || !output}
          className={`flex items-center space-x-2 px-5 py-2 rounded-lg font-medium text-xs font-mono transition cursor-pointer ${
            isRunning
              ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
              : 'bg-amber-600 hover:bg-amber-500 text-white shadow-lg shadow-amber-600/20'
          }`}
        >
          {isRunning ? (
            <>
              <RotateCcw className="w-4 h-4 animate-spin" />
              <span>Analyzing Claims with AI Judge...</span>
            </>
          ) : (
            <>
              <ShieldAlert className="w-4 h-4" />
              <span>Run Hallucination Audit</span>
            </>
          )}
        </button>
      </div>

      {errorMsg && (
        <div className="p-3 rounded-lg bg-rose-950/40 border border-rose-800 text-rose-300 text-xs font-mono">
          {errorMsg}
        </div>
      )}

      {/* Evaluation Results */}
      {result && (
        <div className="space-y-6">
          {/* Executive Scorecard */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 flex flex-col justify-between">
              <span className="text-xs text-zinc-400 font-mono uppercase">FAITHFULNESS SCORE</span>
              <div className="mt-2 flex items-baseline space-x-2">
                <span
                  className={`text-3xl font-extrabold font-mono ${
                    result.faithfulnessScore >= 90
                      ? 'text-emerald-400'
                      : result.faithfulnessScore >= 70
                      ? 'text-amber-400'
                      : 'text-rose-400'
                  }`}
                >
                  {result.faithfulnessScore}%
                </span>
                <span className="text-xs text-zinc-500 font-mono">/ 100%</span>
              </div>
              <div className="w-full bg-zinc-950 rounded-full h-1.5 mt-3 overflow-hidden">
                <div
                  className={`h-full rounded-full ${
                    result.faithfulnessScore >= 90
                      ? 'bg-emerald-500'
                      : result.faithfulnessScore >= 70
                      ? 'bg-amber-500'
                      : 'bg-rose-500'
                  }`}
                  style={{ width: `${result.faithfulnessScore}%` }}
                />
              </div>
            </div>

            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 flex flex-col justify-between">
              <span className="text-xs text-zinc-400 font-mono uppercase">HALLUCINATION RISK</span>
              <div className="mt-2">
                <span
                  className={`text-lg font-bold font-mono px-2.5 py-1 rounded-md inline-block ${
                    result.hallucinationRisk === 'LOW'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      : result.hallucinationRisk === 'MEDIUM'
                      ? 'bg-amber-950 text-amber-300 border border-amber-800'
                      : 'bg-rose-950 text-rose-300 border border-rose-800'
                  }`}
                >
                  {result.hallucinationRisk} RISK
                </span>
              </div>
              <span className="text-[11px] text-zinc-500 font-mono mt-3">
                {result.claims.filter((c) => c.status === 'hallucinated').length} contradictions flagged
              </span>
            </div>

            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 flex flex-col justify-between">
              <span className="text-xs text-zinc-400 font-mono uppercase">VERDICT</span>
              <div className="mt-2 flex items-center space-x-2">
                {result.verdict === 'PASSED' ? (
                  <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                ) : (
                  <XCircle className="w-6 h-6 text-rose-400" />
                )}
                <span
                  className={`text-xl font-bold font-mono ${
                    result.verdict === 'PASSED' ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {result.verdict}
                </span>
              </div>
              <span className="text-[11px] text-zinc-500 font-mono mt-3">
                Guardrail Action: {result.verdict === 'PASSED' ? 'Allow' : 'Flag / Block'}
              </span>
            </div>

            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 flex flex-col justify-between">
              <span className="text-xs text-zinc-400 font-mono uppercase">JUDGE TELEMETRY</span>
              <div className="mt-2 font-mono text-xs space-y-1">
                <div className="text-zinc-300 font-medium">Model: {result.judgeModel || 'gemini-3.8-flash'}</div>
                <div className="text-zinc-500">Eval Latency: {result.evalLatencyMs || 340}ms</div>
              </div>
              <span className="text-[11px] text-zinc-500 font-mono mt-3">
                {result.evaluatedAt}
              </span>
            </div>
          </div>

          {/* Executive Summary */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4">
            <h4 className="text-xs font-mono uppercase text-zinc-400 mb-1">
              EXECUTIVE EVALUATION SUMMARY
            </h4>
            <p className="text-sm text-zinc-200 font-mono leading-relaxed">
              {result.summary}
            </p>
          </div>

          {/* Claim-by-Claim Grounding Breakdown */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <h4 className="text-sm font-bold text-white font-mono flex items-center space-x-2">
                <FileCheck className="w-4 h-4 text-indigo-400" />
                <span>Extracted Claims Grounding Audit ({result.claims.length} claims)</span>
              </h4>
              <div className="flex items-center space-x-3 text-xs font-mono">
                <span className="text-emerald-400">
                  {result.claims.filter((c) => c.status === 'grounded').length} Grounded
                </span>
                <span>•</span>
                <span className="text-rose-400">
                  {result.claims.filter((c) => c.status === 'hallucinated').length} Hallucinated
                </span>
                <span>•</span>
                <span className="text-amber-400">
                  {result.claims.filter((c) => c.status === 'unverifiable').length} Unverifiable
                </span>
              </div>
            </div>

            <div className="space-y-3">
              {result.claims.map((claim, idx) => (
                <div
                  key={idx}
                  className={`p-3 rounded-lg border text-xs font-mono space-y-1.5 ${
                    claim.status === 'grounded'
                      ? 'bg-emerald-950/20 border-emerald-800/60 text-zinc-200'
                      : claim.status === 'hallucinated'
                      ? 'bg-rose-950/30 border-rose-800/80 text-rose-200'
                      : 'bg-amber-950/20 border-amber-800/60 text-amber-200'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start space-x-2">
                      <span
                        className={`text-[10px] px-1.5 py-0.2 rounded uppercase font-bold tracking-wider mt-0.5 ${
                          claim.status === 'grounded'
                            ? 'bg-emerald-900/60 text-emerald-300 border border-emerald-700'
                            : claim.status === 'hallucinated'
                            ? 'bg-rose-900/80 text-rose-300 border border-rose-700'
                            : 'bg-amber-900/60 text-amber-300 border border-amber-700'
                        }`}
                      >
                        {claim.status}
                      </span>
                      <span className="font-semibold text-zinc-100">{claim.claim}</span>
                    </div>
                  </div>

                  <p className="text-zinc-400 text-[11px] pl-3 border-l-2 border-zinc-700/60">
                    <span className="text-zinc-300 font-medium">Reasoning: </span>
                    {claim.reason}
                  </p>

                  {claim.excerptInContext && (
                    <p className="text-emerald-400/90 text-[11px] pl-3 border-l-2 border-emerald-700/60 bg-emerald-950/30 p-1.5 rounded">
                      <span className="font-semibold text-emerald-300">Context Source: </span>
                      "{claim.excerptInContext}"
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Suggested Grounded Rewrite */}
          {result.groundedCorrection && (
            <div className="bg-zinc-900 border border-emerald-500/40 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-mono uppercase text-emerald-400 font-bold flex items-center space-x-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>AI-GENERATED GROUNDED CORRECTION (100% FAITHFUL)</span>
                </h4>
                <button
                  onClick={() => handleCopyRewrite(result.groundedCorrection)}
                  className="text-xs text-zinc-400 hover:text-zinc-200 flex items-center space-x-1 font-mono cursor-pointer"
                >
                  {copiedRewrite ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedRewrite ? 'Copied' : 'Copy Rewrite'}</span>
                </button>
              </div>

              <div className="bg-zinc-950 p-3 rounded-lg border border-zinc-800 text-xs font-mono text-emerald-200/90 leading-relaxed whitespace-pre-wrap">
                {result.groundedCorrection}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
