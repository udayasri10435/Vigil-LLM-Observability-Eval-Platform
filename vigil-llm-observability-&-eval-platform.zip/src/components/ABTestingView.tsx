import React, { useState } from 'react';
import {
  Split,
  Trophy,
  Zap,
  Clock,
  Coins,
  ShieldCheck,
  Play,
  RotateCcw,
  Sparkles,
  CheckCircle,
  HelpCircle,
  ArrowRight,
  TrendingUp,
  Cpu,
} from 'lucide-react';
import { PromptVersion, ABComparisonResult } from '../types';

interface ABTestingViewProps {
  prompts: PromptVersion[];
}

export const ABTestingView: React.FC<ABTestingViewProps> = ({ prompts }) => {
  const [selectedPromptA, setSelectedPromptA] = useState<string>(prompts[0]?.id || '');
  const [selectedPromptB, setSelectedPromptB] = useState<string>(prompts[1]?.id || prompts[0]?.id || '');

  const [modelA, setModelA] = useState<'gemini-3.8-flash' | 'gemini-3.1-flash-lite'>('gemini-3.8-flash');
  const [modelB, setModelB] = useState<'gemini-3.8-flash' | 'gemini-3.1-flash-lite'>('gemini-3.1-flash-lite');

  const [testInput, setTestInput] = useState(
    'Can I get a full refund if I cancel my annual team subscription on day 24? Also explain how my data is stored.'
  );

  const [referenceContext, setReferenceContext] = useState(
    `CloudScale Inc. Refund Policy: Annual subscriptions are eligible for a 100% full refund if cancelled within 30 calendar days of billing. After 30 days, plans are non-refundable. Data retention policy: Upon cancellation, customer workspace data is encrypted and retained for 45 days in AWS us-east-1 before permanent cryptographic erasure.`
  );

  const [isRunning, setIsRunning] = useState(false);
  const [result, setResult] = useState<ABComparisonResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const promptObjA = prompts.find((p) => p.id === selectedPromptA) || prompts[0];
  const promptObjB = prompts.find((p) => p.id === selectedPromptB) || prompts[1] || prompts[0];

  const handleRunComparison = async () => {
    setIsRunning(true);
    setErrorMsg(null);

    try {
      const res = await fetch('/api/eval/ab-test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          variantA: {
            name: `${promptObjA.version} (${modelA})`,
            prompt: promptObjA.template,
            systemInstruction: promptObjA.systemInstruction,
            model: modelA,
            temperature: promptObjA.temperature,
          },
          variantB: {
            name: `${promptObjB.version} (${modelB})`,
            prompt: promptObjB.template,
            systemInstruction: promptObjB.systemInstruction,
            model: modelB,
            temperature: promptObjB.temperature,
          },
          testInput,
          referenceContext,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'A/B evaluation request failed');
      }

      const data = await res.json();
      setResult(data);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Failed to complete comparative evaluation');
    } finally {
      setIsRunning(false);
    }
  };

  const loadPreset = (presetType: 'cost' | 'grounding' | 'json') => {
    if (presetType === 'cost') {
      setModelA('gemini-3.8-flash');
      setModelB('gemini-3.1-flash-lite');
      setTestInput('Summarize the top 3 compliance requirements for SOC2 Type II audit report preparation.');
      setReferenceContext('SOC2 guidelines require: 1. Role-based access control with MFA. 2. Automated audit log retention for 365 days. 3. Continuous vulnerability scanning every 24 hours.');
    } else if (presetType === 'grounding') {
      setSelectedPromptA(prompts[0]?.id || '');
      setSelectedPromptB(prompts[2]?.id || prompts[0]?.id || '');
      setTestInput('What is the refund window for annual licenses and how is my data treated upon cancellation?');
      setReferenceContext('CloudScale Refund Policy: 30-day full refund for annual plans. Data is encrypted and retained for 45 days before permanent wipe.');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white font-mono flex items-center space-x-2">
            <Split className="w-5 h-5 text-indigo-400" />
            <span>A/B Comparative Testing Arena</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Run side-by-side prompt or model executions. Compare latency, token cost, and LLM-as-a-judge blind quality scores.
          </p>
        </div>

        {/* Quick Presets */}
        <div className="flex items-center space-x-2">
          <span className="text-xs text-zinc-500 font-mono hidden sm:inline">PRESETS:</span>
          <button
            onClick={() => loadPreset('cost')}
            className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-mono transition cursor-pointer"
          >
            Flash vs Flash-Lite
          </button>
          <button
            onClick={() => loadPreset('grounding')}
            className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-mono transition cursor-pointer"
          >
            Strict vs Naive Prompt
          </button>
        </div>
      </div>

      {/* Configuration Grid: Variant A vs Variant B */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Variant A Card */}
        <div className="bg-zinc-900/90 border border-indigo-500/50 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="w-6 h-6 rounded-full bg-indigo-600/30 text-indigo-400 flex items-center justify-center font-mono text-xs font-bold border border-indigo-500/40">
                A
              </span>
              <h3 className="text-sm font-bold text-white font-mono">Variant A (Baseline)</h3>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
              ACTIVE
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[11px] font-mono text-zinc-400 block mb-1">
                PROMPT VERSION
              </label>
              <select
                value={selectedPromptA}
                onChange={(e) => setSelectedPromptA(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-1.5 text-xs text-zinc-200 font-mono focus:border-indigo-500 outline-none"
              >
                {prompts.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.version} - {p.name.slice(0, 20)}...
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[11px] font-mono text-zinc-400 block mb-1">
                MODEL
              </label>
              <select
                value={modelA}
                onChange={(e) => setModelA(e.target.value as any)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-1.5 text-xs text-zinc-200 font-mono focus:border-indigo-500 outline-none"
              >
                <option value="gemini-3.8-flash">gemini-3.8-flash (Standard)</option>
                <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (Cost-Opt)</option>
              </select>
            </div>
          </div>

          <div className="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800/80 text-[11px] font-mono text-zinc-400 line-clamp-3">
            {promptObjA.systemInstruction || promptObjA.template}
          </div>
        </div>

        {/* Variant B Card */}
        <div className="bg-zinc-900/90 border border-cyan-500/50 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="w-6 h-6 rounded-full bg-cyan-600/30 text-cyan-400 flex items-center justify-center font-mono text-xs font-bold border border-cyan-500/40">
                B
              </span>
              <h3 className="text-sm font-bold text-white font-mono">Variant B (Challenger)</h3>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
              CANDIDATE
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[11px] font-mono text-zinc-400 block mb-1">
                PROMPT VERSION
              </label>
              <select
                value={selectedPromptB}
                onChange={(e) => setSelectedPromptB(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-1.5 text-xs text-zinc-200 font-mono focus:border-cyan-500 outline-none"
              >
                {prompts.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.version} - {p.name.slice(0, 20)}...
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[11px] font-mono text-zinc-400 block mb-1">
                MODEL
              </label>
              <select
                value={modelB}
                onChange={(e) => setModelB(e.target.value as any)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-1.5 text-xs text-zinc-200 font-mono focus:border-cyan-500 outline-none"
              >
                <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (Cost-Opt)</option>
                <option value="gemini-3.8-flash">gemini-3.8-flash (Standard)</option>
              </select>
            </div>
          </div>

          <div className="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800/80 text-[11px] font-mono text-zinc-400 line-clamp-3">
            {promptObjB.systemInstruction || promptObjB.template}
          </div>
        </div>
      </div>

      {/* Test Input & Reference Context */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-mono text-zinc-300 block mb-1">
              TEST INPUT / QUERY
            </label>
            <textarea
              rows={3}
              value={testInput}
              onChange={(e) => setTestInput(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2.5 text-xs text-zinc-200 font-mono focus:border-indigo-500 outline-none"
              placeholder="Enter user test prompt..."
            />
          </div>

          <div>
            <label className="text-xs font-mono text-zinc-300 block mb-1">
              GROUND TRUTH REFERENCE CONTEXT (RAG / Knowledge base)
            </label>
            <textarea
              rows={3}
              value={referenceContext}
              onChange={(e) => setReferenceContext(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2.5 text-xs text-zinc-200 font-mono focus:border-indigo-500 outline-none"
              placeholder="Enter verified facts used to judge hallucinations..."
            />
          </div>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-zinc-800">
          <span className="text-xs text-zinc-400 font-mono">
            Concurrent execution will run both models + blind AI judge evaluation.
          </span>

          <button
            onClick={handleRunComparison}
            disabled={isRunning || !testInput}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium text-xs transition cursor-pointer ${
              isRunning
                ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/20'
            }`}
          >
            {isRunning ? (
              <>
                <RotateCcw className="w-4 h-4 animate-spin" />
                <span>Running Arena & Judge...</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                <span>Run A/B Comparison</span>
              </>
            )}
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-lg bg-rose-950/40 border border-rose-800 text-rose-300 text-xs font-mono">
            {errorMsg}
          </div>
        )}
      </div>

      {/* Results Comparison Strip & Scorecards */}
      {result && (
        <div className="space-y-6">
          {/* Executive Judge Verdict Card */}
          <div className="bg-gradient-to-r from-zinc-900 via-indigo-950/40 to-zinc-900 border border-indigo-500/50 rounded-xl p-5 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800/80 pb-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center">
                  <Trophy className="w-5 h-5 text-amber-400" />
                </div>
                <div>
                  <span className="text-xs font-mono uppercase text-amber-400 tracking-wider">
                    LLM-AS-A-JUDGE BLIND VERDICT
                  </span>
                  <h3 className="text-lg font-bold text-white font-mono">
                    WINNER: {result.judge.winner.replace('_', ' ')}
                  </h3>
                </div>
              </div>

              {/* Head-to-Head Scores */}
              <div className="flex items-center space-x-6 text-sm font-mono">
                <div className="text-center">
                  <span className="text-zinc-400 text-xs block">VARIANT A SCORE</span>
                  <span className="text-indigo-400 font-bold text-lg">
                    {result.judge.scoreA}/100
                  </span>
                </div>
                <span className="text-zinc-600 text-lg">vs</span>
                <div className="text-center">
                  <span className="text-zinc-400 text-xs block">VARIANT B SCORE</span>
                  <span className="text-cyan-400 font-bold text-lg">
                    {result.judge.scoreB}/100
                  </span>
                </div>
              </div>
            </div>

            <p className="text-xs text-zinc-300 font-mono mt-3 leading-relaxed">
              <span className="text-indigo-400 font-semibold">Judge Rationale: </span>
              {result.judge.verdictSummary}
            </p>

            {/* Criteria Breakdown Grid */}
            <div className="grid grid-cols-3 gap-3 mt-4 pt-3 border-t border-zinc-800/60 text-xs font-mono">
              <div className="bg-zinc-950/70 p-2.5 rounded-lg border border-zinc-800/60">
                <span className="text-zinc-500 block text-[10px]">RELEVANCE & INSTRUCTIONS</span>
                <div className="flex justify-between mt-1">
                  <span className="text-indigo-400 font-bold">A: {result.judge.criteriaScores.relevanceA}%</span>
                  <span className="text-cyan-400 font-bold">B: {result.judge.criteriaScores.relevanceB}%</span>
                </div>
              </div>

              <div className="bg-zinc-950/70 p-2.5 rounded-lg border border-zinc-800/60">
                <span className="text-zinc-500 block text-[10px]">ACCURACY & GROUNDEDNESS</span>
                <div className="flex justify-between mt-1">
                  <span className="text-indigo-400 font-bold">A: {result.judge.criteriaScores.accuracyA}%</span>
                  <span className="text-cyan-400 font-bold">B: {result.judge.criteriaScores.accuracyB}%</span>
                </div>
              </div>

              <div className="bg-zinc-950/70 p-2.5 rounded-lg border border-zinc-800/60">
                <span className="text-zinc-500 block text-[10px]">CLARITY & CONCISENESS</span>
                <div className="flex justify-between mt-1">
                  <span className="text-indigo-400 font-bold">A: {result.judge.criteriaScores.clarityA}%</span>
                  <span className="text-cyan-400 font-bold">B: {result.judge.criteriaScores.clarityB}%</span>
                </div>
              </div>
            </div>
          </div>

          {/* Side-by-Side Outputs & Telemetry */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Output A */}
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
                <div className="flex items-center space-x-2">
                  <span className="w-5 h-5 rounded-full bg-indigo-600/30 text-indigo-400 flex items-center justify-center font-mono text-xs font-bold">
                    A
                  </span>
                  <span className="font-mono text-xs font-bold text-white">
                    {result.variantA.name}
                  </span>
                </div>
                <div className="flex items-center space-x-3 text-[11px] font-mono text-zinc-400">
                  <span className="flex items-center space-x-1">
                    <Clock className="w-3 h-3" />
                    <span>{result.variantA.latencyMs}ms</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <Coins className="w-3 h-3 text-amber-400" />
                    <span>${result.variantA.cost.toFixed(6)}</span>
                  </span>
                </div>
              </div>

              <div className="bg-zinc-950 p-3 rounded-lg border border-zinc-800 text-xs text-zinc-200 font-mono whitespace-pre-wrap min-h-[160px]">
                {result.variantA.output}
              </div>

              <div className="flex justify-between text-[11px] font-mono text-zinc-500">
                <span>Prompt tokens: {result.variantA.inputTokens}</span>
                <span>Completion: {result.variantA.outputTokens}</span>
              </div>
            </div>

            {/* Output B */}
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
                <div className="flex items-center space-x-2">
                  <span className="w-5 h-5 rounded-full bg-cyan-600/30 text-cyan-400 flex items-center justify-center font-mono text-xs font-bold">
                    B
                  </span>
                  <span className="font-mono text-xs font-bold text-white">
                    {result.variantB.name}
                  </span>
                </div>
                <div className="flex items-center space-x-3 text-[11px] font-mono text-zinc-400">
                  <span className="flex items-center space-x-1">
                    <Clock className="w-3 h-3" />
                    <span>{result.variantB.latencyMs}ms</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <Coins className="w-3 h-3 text-amber-400" />
                    <span>${result.variantB.cost.toFixed(6)}</span>
                  </span>
                </div>
              </div>

              <div className="bg-zinc-950 p-3 rounded-lg border border-zinc-800 text-xs text-zinc-200 font-mono whitespace-pre-wrap min-h-[160px]">
                {result.variantB.output}
              </div>

              <div className="flex justify-between text-[11px] font-mono text-zinc-500">
                <span>Prompt tokens: {result.variantB.inputTokens}</span>
                <span>Completion: {result.variantB.outputTokens}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
