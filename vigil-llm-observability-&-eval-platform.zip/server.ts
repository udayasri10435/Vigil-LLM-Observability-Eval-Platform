import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';

dotenv.config();

const app = express();
app.use(express.json({ limit: '10mb' }));

// Initialize Gemini Client
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Pricing constants ($ per 1M tokens)
const MODEL_PRICING: Record<string, { input: number; output: number }> = {
  'gemini-3.8-flash': { input: 0.15, output: 0.60 },
  'gemini-3.1-flash-lite': { input: 0.075, output: 0.30 },
};

function calculateCost(model: string, inputTokens: number, outputTokens: number): number {
  const pricing = MODEL_PRICING[model] || MODEL_PRICING['gemini-3.8-flash'];
  const cost = (inputTokens / 1_000_000) * pricing.input + (outputTokens / 1_000_000) * pricing.output;
  return Number(cost.toFixed(6));
}

// Resilient wrapper: fall back between gemini-3.8-flash and gemini-3.1-flash-lite
async function generateWithFallback(primaryModel: string, contents: any, config?: any) {
  const fallbackModel = primaryModel === 'gemini-3.8-flash' ? 'gemini-3.1-flash-lite' : 'gemini-3.8-flash';
  try {
    return await ai.models.generateContent({
      model: primaryModel,
      contents,
      config,
    });
  } catch (err: any) {
    console.warn(`Primary model ${primaryModel} failed (${err.message}), retrying with ${fallbackModel}...`);
    return await ai.models.generateContent({
      model: fallbackModel,
      contents,
      config,
    });
  }
}

// Health & Status
app.get('/api/status', (req, res) => {
  res.json({
    status: 'operational',
    hasKey: Boolean(apiKey && apiKey.length > 5),
    activeModel: 'gemini-3.8-flash',
    supportedModels: ['gemini-3.8-flash', 'gemini-3.1-flash-lite'],
    timestamp: new Date().toISOString(),
  });
});

// Run a prompt / trace
app.post('/api/run-prompt', async (req, res) => {
  try {
    const {
      prompt,
      systemInstruction,
      model = 'gemini-3.8-flash',
      temperature = 0.7,
      topP = 0.95,
      variables = {},
    } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    // Variable interpolation
    let resolvedPrompt = prompt;
    for (const [key, val] of Object.entries(variables)) {
      const regex = new RegExp(`{{\\s*${key}\\s*}}`, 'g');
      resolvedPrompt = resolvedPrompt.replace(regex, String(val));
    }

    const startTime = Date.now();
    const targetModel = model === 'gemini-3.1-flash-lite' ? 'gemini-3.1-flash-lite' : 'gemini-3.8-flash';
    const response = await generateWithFallback(targetModel, resolvedPrompt, {
      systemInstruction: systemInstruction || undefined,
      temperature: Number(temperature),
      topP: Number(topP),
    });
    const latencyMs = Date.now() - startTime;

    const text = response.text || '';
    const usage = response.usageMetadata || {};
    const inputTokens = usage.promptTokenCount || Math.ceil((resolvedPrompt.length + (systemInstruction?.length || 0)) / 4);
    const outputTokens = usage.candidatesTokenCount || Math.ceil(text.length / 4);
    const totalTokens = usage.totalTokenCount || (inputTokens + outputTokens);
    const cost = calculateCost(model, inputTokens, outputTokens);

    res.json({
      text,
      latencyMs,
      inputTokens,
      outputTokens,
      totalTokens,
      cost,
      model,
      resolvedPrompt,
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error('Error running prompt:', err);
    res.status(500).json({
      error: err.message || 'Failed to generate response from Gemini API',
    });
  }
});

// Hallucination & Faithfulness Evaluator (LLM-as-a-Judge)
app.post('/api/eval/hallucination', async (req, res) => {
  try {
    const { context, prompt, output } = req.body;

    if (!context || !output) {
      return res.status(400).json({ error: 'Both context and output are required for hallucination evaluation.' });
    }

    const startTime = Date.now();

    const evaluationPrompt = `
You are an expert AI Safety & Observability Judge specializing in Hallucination Detection, Groundedness, and Faithfulness evaluation in LLMs.
Evaluate whether the following "Generated Output" is factually faithful and strictly grounded in the "Reference Context".
If the output contains facts, statistics, names, claims, or deductions not present or directly contradicted by the context, flag them as hallucinations or unverifiable.

[REFERENCE CONTEXT]:
${context}

[USER PROMPT]:
${prompt || 'N/A'}

[GENERATED OUTPUT]:
${output}

Analyze every claim carefully. Return a strict JSON evaluation matching the required schema.
`;

    const response = await generateWithFallback('gemini-3.8-flash', evaluationPrompt, {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          faithfulnessScore: {
            type: Type.NUMBER,
            description: 'Score from 0 (completely ungrounded/hallucinated) to 100 (100% strictly faithful).',
          },
          hallucinationRisk: {
            type: Type.STRING,
            description: 'Risk category: LOW (90-100% faithful), MEDIUM (70-89% faithful), or CRITICAL (<70% faithful).',
          },
          verdict: {
            type: Type.STRING,
            description: 'Overall verdict: PASSED, WARNING, or FAILED.',
          },
          summary: {
            type: Type.STRING,
            description: 'Concise executive explanation of the faithfulness assessment.',
          },
          claims: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                claim: { type: Type.STRING, description: 'The specific assertion extracted from the output' },
                status: {
                  type: Type.STRING,
                  description: 'grounded (supported by context), hallucinated (contradicted or fabricated), or unverifiable (extrapolated beyond context)',
                },
                reason: { type: Type.STRING, description: 'Reasoning why this claim is grounded or hallucinated' },
                excerptInContext: { type: Type.STRING, description: 'Direct matching quote from reference context if grounded' },
              },
              required: ['claim', 'status', 'reason'],
            },
          },
          groundedCorrection: {
            type: Type.STRING,
            description: 'An edited, strictly factual rewrite of the output that eliminates all hallucinations.',
          },
        },
        required: ['faithfulnessScore', 'hallucinationRisk', 'verdict', 'summary', 'claims', 'groundedCorrection'],
      },
    });

    const latencyMs = Date.now() - startTime;
    const jsonStr = response.text?.trim() || '{}';
    const parsed = JSON.parse(jsonStr);

    res.json({
      ...parsed,
      evalLatencyMs: latencyMs,
      judgeModel: 'gemini-3.8-flash',
      evaluatedAt: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error('Error running hallucination evaluation:', err);
    res.status(500).json({
      error: err.message || 'Failed to evaluate hallucination with Gemini API',
    });
  }
});

// A/B Test Runner & Comparative Judge
app.post('/api/eval/ab-test', async (req, res) => {
  try {
    const {
      variantA,
      variantB,
      testInput,
      referenceContext,
    } = req.body;

    if (!variantA || !variantB || !testInput) {
      return res.status(400).json({ error: 'Variant A, Variant B, and test input are required.' });
    }

    // Execute Variant A
    const startA = Date.now();
    const promptAText = variantA.prompt.replace(/{{\s*query\s*}}/g, testInput).replace(/{{\s*context\s*}}/g, referenceContext || '');
    const resA = await generateWithFallback(
      variantA.model || 'gemini-3.8-flash',
      promptAText,
      {
        systemInstruction: variantA.systemInstruction || undefined,
        temperature: variantA.temperature ?? 0.7,
      }
    );
    const latencyA = Date.now() - startA;
    const textA = resA.text || '';
    const usageA = resA.usageMetadata || {};
    const inTokensA = usageA.promptTokenCount || Math.ceil(promptAText.length / 4);
    const outTokensA = usageA.candidatesTokenCount || Math.ceil(textA.length / 4);
    const costA = calculateCost(variantA.model || 'gemini-3.8-flash', inTokensA, outTokensA);

    // Execute Variant B
    const startB = Date.now();
    const promptBText = variantB.prompt.replace(/{{\s*query\s*}}/g, testInput).replace(/{{\s*context\s*}}/g, referenceContext || '');
    const resB = await generateWithFallback(
      variantB.model || 'gemini-3.1-flash-lite',
      promptBText,
      {
        systemInstruction: variantB.systemInstruction || undefined,
        temperature: variantB.temperature ?? 0.7,
      }
    );
    const latencyB = Date.now() - startB;
    const textB = resB.text || '';
    const usageB = resB.usageMetadata || {};
    const inTokensB = usageB.promptTokenCount || Math.ceil(promptBText.length / 4);
    const outTokensB = usageB.candidatesTokenCount || Math.ceil(textB.length / 4);
    const costB = calculateCost(variantB.model || 'gemini-3.1-flash-lite', inTokensB, outTokensB);

    // LLM-as-a-Judge Blind Comparison
    const judgePrompt = `
You are an expert AI Benchmark Judge comparing two LLM responses to a user input.
Evaluate both outputs objectively on:
1. Instruction Following & Relevance
2. Factuality & Accuracy (Reference Context: ${referenceContext || 'General knowledge'})
3. Conciseness & Clarity
4. Tone & Quality

User Input:
${testInput}

Response Variant A:
${textA}

Response Variant B:
${textB}

Determine the winner (Variant A, Variant B, or TIE). Score each on a scale of 0-100 and justify your decision.
`;

    const judgeRes = await generateWithFallback('gemini-3.8-flash', judgePrompt, {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          winner: { type: Type.STRING, description: 'VARIANT_A, VARIANT_B, or TIE' },
          scoreA: { type: Type.NUMBER, description: 'Score for Variant A (0-100)' },
          scoreB: { type: Type.NUMBER, description: 'Score for Variant B (0-100)' },
          criteriaScores: {
            type: Type.OBJECT,
            properties: {
              relevanceA: { type: Type.NUMBER },
              relevanceB: { type: Type.NUMBER },
              accuracyA: { type: Type.NUMBER },
              accuracyB: { type: Type.NUMBER },
              clarityA: { type: Type.NUMBER },
              clarityB: { type: Type.NUMBER },
            },
            required: ['relevanceA', 'relevanceB', 'accuracyA', 'accuracyB', 'clarityA', 'clarityB'],
          },
          verdictSummary: { type: Type.STRING, description: 'Executive verdict rationale' },
        },
        required: ['winner', 'scoreA', 'scoreB', 'criteriaScores', 'verdictSummary'],
      },
    });

    const judgeData = JSON.parse(judgeRes.text?.trim() || '{}');

    res.json({
      variantA: {
        name: variantA.name || 'Variant A',
        model: variantA.model,
        output: textA,
        latencyMs: latencyA,
        inputTokens: inTokensA,
        outputTokens: outTokensA,
        cost: costA,
        score: judgeData.scoreA,
      },
      variantB: {
        name: variantB.name || 'Variant B',
        model: variantB.model,
        output: textB,
        latencyMs: latencyB,
        inputTokens: inTokensB,
        outputTokens: outTokensB,
        cost: costB,
        score: judgeData.scoreB,
      },
      judge: judgeData,
      delta: {
        latencyMs: latencyB - latencyA,
        costSavingsPercent: costA > 0 ? Number((((costA - costB) / costA) * 100).toFixed(1)) : 0,
        scoreDiff: (judgeData.scoreA || 0) - (judgeData.scoreB || 0),
      },
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error('Error in AB test evaluation:', err);
    res.status(500).json({ error: err.message || 'Failed to complete AB test evaluation' });
  }
});

// Batch benchmark evaluation endpoint
app.post('/api/eval/batch', async (req, res) => {
  try {
    const { promptTemplate, systemInstruction, testCases = [] } = req.body;
    if (!promptTemplate || !testCases.length) {
      return res.status(400).json({ error: 'Prompt template and test cases are required' });
    }

    const results = [];
    for (const testCase of testCases) {
      const resolved = promptTemplate.replace(/{{\s*query\s*}}/g, testCase.input);
      const start = Date.now();
      const response = await generateWithFallback('gemini-3.8-flash', resolved, {
        systemInstruction: systemInstruction || undefined,
      });
      const latency = Date.now() - start;
      const text = response.text || '';
      const usage = response.usageMetadata || {};
      const inTokens = usage.promptTokenCount || Math.ceil(resolved.length / 4);
      const outTokens = usage.candidatesTokenCount || Math.ceil(text.length / 4);
      const cost = calculateCost('gemini-3.8-flash', inTokens, outTokens);

      const isPass = testCase.expectedKeyword
        ? text.toLowerCase().includes(testCase.expectedKeyword.toLowerCase())
        : true;

      results.push({
        id: testCase.id,
        input: testCase.input,
        output: text,
        expected: testCase.expectedKeyword,
        passed: isPass,
        latencyMs: latency,
        tokens: inTokens + outTokens,
        cost,
      });
    }

    const totalPassed = results.filter((r) => r.passed).length;
    const avgLatency = Math.round(results.reduce((acc, r) => acc + r.latencyMs, 0) / results.length);
    const totalCost = Number(results.reduce((acc, r) => acc + r.cost, 0).toFixed(6));

    res.json({
      passRate: Number(((totalPassed / results.length) * 100).toFixed(1)),
      totalCases: results.length,
      passedCases: totalPassed,
      avgLatencyMs: avgLatency,
      totalCost,
      results,
    });
  } catch (err: any) {
    console.error('Error in batch eval:', err);
    res.status(500).json({ error: err.message || 'Batch evaluation failed' });
  }
});

// Vite middleware / production static serving
const isProd = process.env.NODE_ENV === 'production';
const port = 3000;

async function startServer() {
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
    app.use('*', async (req, res, next) => {
      const url = req.originalUrl;
      try {
        let template = fs.readFileSync(path.resolve('index.html'), 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e: any) {
        vite.ssrFixStacktrace(e);
        next(e);
      }
    });
  } else {
    app.use(express.static('dist'));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve('dist/index.html'));
    });
  }

  app.listen(Number(port), '0.0.0.0', () => {
    console.log(`Vigil LLM Observability server active at http://0.0.0.0:${port}`);
  });
}

startServer();
